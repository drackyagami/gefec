<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pest extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'plant_target',
        'image',
        'status',
    ];
    public function symptom()
    {
        return $this->hasOne(Symptom::class,'pest_id','id');
    }
    public function action()
    {
        return $this->hasOne(Action::class,'pest_id','id');
    }
}
