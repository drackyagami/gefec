<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Action extends Model
{
    use HasFactory;

    public $incrementing = false;

    protected $fillable = [
        'pest_id',
        'detail'
    ];
    public function pest()
    {
        return $this->belongsTo(Pest::class,'pest_id');
        
    }
}
