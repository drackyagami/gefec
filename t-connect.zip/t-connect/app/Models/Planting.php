<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Planting extends Model
{
    use HasFactory;

    protected $fillable = [
        'plant_id',
        'land_id',
        'planting',
        'status',
    ];
    public function land()
    {
       return $this->belongsTo(Land::class,'land_id','id');
    }
}
