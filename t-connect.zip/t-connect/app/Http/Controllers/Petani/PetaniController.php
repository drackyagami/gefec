<?php

namespace App\Http\Controllers\Petani;

use App\Http\Controllers\Controller;
use App\Models\Land;
use App\Models\Pest;
use App\Models\Plant;
use App\Models\Planting;
use App\Models\Report;
use App\Models\Result;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth as FacadesAuth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use League\CommonMark\Extension\Table\Table;

class PetaniController extends Controller
{
    public function index(){
       
        $data = [
            'lahan' => Land::whereUser_id(Auth::user()->id)->count(),
            'luas' => Land::whereUser_id(Auth::user()->id)->sum('large'),
            'diagnosa' => Report::whereUser_id(Auth::user()->id)->count(),
            'pemanenan'=>Land::whereUser_id(Auth::user()->id)->join("plantings", "plantings.land_id", "=", "lands.id")->where('plantings.status',true)->get()->count()
            // 'jmlpnn' => Land::whereLand_id($id2)->join("plantings", "plantings.land_id", "=", "lands.id")->where('plantings.status',true)->get()->count()
        ];
        
        // $data = Planting::whereStatus(true)->count();
        return view('petani.dashboard', compact('data'));
    }

    public function dlahan(){
        $data = [
            'lahan' => Land::whereUser_id(Auth::user()->id)->get()
        ];
        return view('petani.datalahan', compact('data'));
    }
    
    public function addlahan(Request $request){
        //set validation
        $this->validate($request, [
            'name' => 'required|string|unique:lands',
            'large' => 'required',
            'address' => 'required|string|max:255',
            'city' => 'required|string',
            'province' => 'required|string',
            'lat' => 'required|string',
            'long' => 'required|string',
        ]);

        // Menyimpan data lahan ke DB
        Land::create([
            'name' => $request->name,
            'large' => $request->large,
            'lat' => $request->lat,
            'long' => $request->long,
            'address' => $request->address,
            'city' => $request->city,
            'province' => $request->province,
            'user_id' => Auth::user()->id,
            'status' => true,
        ]);

        return back();
    }
    //hapus lahan
    public function deletelahan($id)
{
	DB::table('lands')->where('id',$id)->delete();
    return back();
}
public function edit_lahan($id)
{
    $lahan = Land::find($id);

    return view('petani.edit-tanaman', compact('lahan'));
}
//Edit lahan
public function update_lahan(Request $request, $id){
    // dd($request->all());
    // $request->validate([
    //     'name'=>'required',
    //     'long'=>'required',
    //     'lat'=>'required',
    //     'large'=>'required',
    //     'address'=>'required',
    //     'city'=>'required',
    //     'province'=>'required',
    // ]);

    $land = Land::find($id);
    $land->name = $request->name;
    $land->long = $request->long;
    $land->lat = $request->lat;
    $land->large = $request->large;
    $land->address = $request->address;
    $land->city = $request->city;
    $land->province = $request->province;
    $land->save();
    return redirect('/petani/datalahan');
}
    // PR
    public function dtanaman(){

        // $plant = Planting::whereId(Auth::user()->id)->first();
        $data = [
            'land' => Land::whereUser_id(Auth::user()->id)->get(),
            'plant' => new Plant(),
            'lahan' => Land::whereUser_id(Auth::user()->id)->join("plantings", "plantings.land_id", "=", "lands.id")->get(),
        ];
      
        return view('petani.datatanaman',compact('data'));
    }
    
    public function addtanaman(Request $request){
        //set validation
        $this->validate($request, [
            'land' => 'required|exists:lands,id',
            'plant' => 'required|exists:plants,id',
            'date' => 'required',
        ]);
        
        // Menyimpan data lahan ke DB
        Planting::create([
            'plant_id' => $request->plant,
            'land_id' => $request->land,
            'planting' => $request->date,
            'status' => false,
        ]);

        return back();
    }
    //hapustanaman
    public function hapustanaman($id){
    
        DB::table('plantings')->where('id',$id)->delete();
    return back();
    }
    //ganti status
    public function gantipanen(Request $request, $id){
        
        $plant=Planting::find($id);
        $status = $plant->status;
        
        if ($status == false) {
            $status = !$status;
        }else{
            $status = true;
        }

        $data =[
            'status' => $status  
        ];
        
        $plant->update($data);

        return back();

    }
    //edit status
    public function editstatus(){
    
    }

    public function dhama(){
        $data = [
            'lahan' => new Land(),
            'plant' => new Plant(),
            'land' => Land::all(),
            'report' => Report::whereUser_id(Auth::user()->id)
                        ->orderBy('code')->paginate(2), 
            'result' => new Result(),
            'pest' => new Pest(),
        ];
        return view('petani.hamapetani', compact('data'));
    }
    // // PR
    // public function addhama(Request $request){
    //     //set validation
    //     $this->validate($request, [
    //         'land' => 'required|exists:lands,id',
    //         'image' => 'required',
    //     ]);
    //     dd($request->all());
        
    //     $data = Report::orderBy('code')->orderByDesc('code')->value('code');
    //     $list = (int) substr($data, 3, 7);
    //     $list++;
    //     $code = "RLP" . sprintf("%07s", $list);
    //     $fileName = "img-r-" . Str::slug($code) . "." . $request->sample->extension();

    //     // mengambl data user login
    //     $user = $request->user();

    //     // Menyimpan data lahan ke DB
    //     $report = Report::create([
    //         'code' => $code,
    //         'user_id' => $user->id,
    //         'land_id' => Land::whereName($request->land)->value('id'),
    //         'sample' => $fileName,
    //     ]);

    //     // Menyimpan gambar ke server
    //     $request->sample->move(public_path('image/report'), $fileName);

    //     return back();
    // }

    public function profilepetani(){
        return view('petani.profile');
    }
    //Edit Profil
    public function editprofile(Request $request){
        
        $request->validate([
            'username'=>'required',
            'email'=>'required',
            'address'=>'required',
            'city'=>'required',
            'province'=>'required',
            'birth'=>'required',
            
        ]);
        User::find(Auth::user()->id)->update($request->all());
        return back()->with(['messagge'=>'Profile sudah di Ubah']);
    }

    public function passwordptn(){
        return view('petani.passwordptn');
    }
        //edit password
        public function editpassword(Request $request){
            $request->validate([
                'password_lama'=>'required',
                'password_baru'=>'required',
                'konfirmasi_password'=>'same:password_baru',
            ]);
    
            $check = Hash::check($request->password_lama, Auth::user()->password);
            if ($check == true) {
                
                User::find(Auth::user()->id)->update(['password'=>Hash::make($request->password_baru)]);
                return back();
            }
            return redirect('/petani/passwordptn')->with(['message' => 'Password lama Anda salah!']);
    
    
            
        }
        

    public function ktanaman(){
        return view('petani.kondisitanaman');
    }
    public function ttanaman(){
        return view('petani.tindakantanaman');
    }
    public function perangkattnm(){
        return view('petani.perangkattnm');
    }
}
