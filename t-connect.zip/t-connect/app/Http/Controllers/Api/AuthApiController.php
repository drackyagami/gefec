<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Land;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Foundation\Auth\User as AuthUser;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthApiController extends Controller
{
    public function login(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
            'password' => 'required|string',
            'device_name' => 'required',
        ]);
        
        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed authenticated",
                "detail" => $validator->errors(),
            ], 401);
        }

        // Mengambil data akun
        $user = User::whereEmail($request->email)->first();
        
        // Cek password
        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed authenticated",
                "detail" => "wrong password",
            ], 401);
        }

        // membuat token akses midellware
        $token =  $user->createToken($request->device_name)->plainTextToken;

        // Mengirim response ke perequest
        return response()->json([
            "code" => 202,
            "status" => "success",
            "message" => "login successfully",
            "data" => [
                "id" =>  $user->id,
                "username" => $user->username,
                "email" => $user->email,
                "birth" => $user->birth,
                "address" => $user->address,
                "city" => $user->city,
                "province" => $user->province,
                "lat" => $user->lat,
                "long" => $user->long,
                "phone" => $user->phone,
                "avatar" => $user->avatar,
                "created_at" => $user->created_at,
                "updated_at" => $user->updated_at,
                "land_active" => Land::whereUser_id($user->id)->whereStatus(true)->count(),
                "land_inactive" => Land::whereUser_id($user->id)->whereStatus(false)->count()
            ],
            "token" => $token,
        ], 202);
    }

    public function register(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            'username' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'device_name' => 'required',
        ]);
        
        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed input format",
                "detail" => $validator->errors(),
            ], 401);
        }

        // Menyimpan data akun ke DB
        $user = User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'level' => 2,
            'status' => true,
        ]);

        // membuat token akses midellware
        $token =  $user->createToken($request->device_name)->plainTextToken;

        // Mengirim response ke perequest
        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "register successfully",
            "link" => [
                "link" => "http://nidumila.com",
                "class" => "http://alishatera.com"
            ],
            "data" => [
                "id" =>  $user->id,
                "username" => $user->username,
                "email" => $user->email,
                "birth" => $user->birth,
                "address" => $user->address,
                "city" => $user->city,
                "province" => $user->province,
                "lat" => $user->lat,
                "long" => $user->long,
                "phone" => $user->phone,
                "avatar" => $user->avatar,
                "created_at" => $user->created_at,
                "updated_at" => $user->updated_at,
                "land_active" => Land::whereUser_id($user->id)->whereStatus(true)->count(),
                "land_inactive" => Land::whereUser_id($user->id)->whereStatus(false)->count()
            ],
            "token" => $token,
        ], 201);
    }

    public function fcm(Request $request)
    {
        $user = User::find($request->user()->id);
        $user->fcm_token = $request->fcm_token;
        $user->save();

        return response()->json([
            "code" => 202,
            "status" => "success",
            "message" => "login successfully",
        ], 202);
    }

    public function forgot(Request $request)
    {
        $request->validate([
            'email' => 'required|exists:users',
            'device_name' => 'required',
        ]);

        $user = User::whereEmail($request->email)->first();

        if (!$user) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "Email not registered, please check again your email",
            ], 401);
        }

        $token =  $user->createToken($request->device_name)->plainTextToken;

        return response()->json([
            "code" => 202,
            "status" => "success",
            "message" => "email is register",
            "token" => $token,
        ], 202);
    }

    public function password(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            'password' => 'required|string|min:8',
        ]);

        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed input format",
                "detail" => $validator->errors(),
            ], 401);
        }

        $user = $request->user();
        $user->password = Hash::make($request->password);
        $user->save();

        $request->user()->currentAccessToken()->delete();

        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "password has updated",
        ], 201);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json([
            "code" => 202,
            "status" => "success",
            "message" => "logout successfully",
        ], 202);
    }
}
