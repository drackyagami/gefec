<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\Land;
use App\Models\Plant;
use App\Models\Planting;
use App\Models\Report;
use App\Models\Result;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LahanApiController extends Controller
{
    public function getLand(Request $request)
    {
        $land = [];
        // mengambl data user login
        $user = $request->user();
        // mengambil data lahan
        $lahan = Land::whereUser_id($user->id)->whereStatus(true)
                    ->orderByDesc("created_at")->get();
                    
        foreach ($lahan as $key => $value) {
            $plant = Planting::whereLand_id($value->id)->get();
            $data = [
                "id" =>  $value->id,
                "name" => $value->name,
                "large" => $value->large,
                "plant" => count($plant),
                "lat" => $value->lat,
                "long" => $value->long,
                "address" => $value->address,
                "city" => $value->city,
                "province" => $value->province,
                "registered" => Carbon::parse($value->created_at)->format('Y-m-d'),
            ];
            array_push($land, $data);
        }

        // Mengirim response ke perequest
        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "get land data successfully",
            "amount" => count($land),
            "data" => $land
        ], 202);
    }

    public function addLand(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'large' => 'required',
            'address' => 'required|string|max:255',
            'city' => 'required|string',
            'province' => 'required|string',
            'lat' => 'required|string',
            'long' => 'required|string',
        ]);

        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed input format",
                "detail" => $validator->errors(),
            ], 401);
        }

        // mengambl data user login
        $user = $request->user();

        // Menyimpan data lahan ke DB
        Land::create([
            'name' => $request->name,
            'large' => $request->large,
            'lat' => $request->lat,
            'long' => $request->long,
            'address' => $request->address,
            'city' => $request->city,
            'province' => $request->province,
            'user_id' => $user->id,
            'status' => true,
        ]);

        // Mengirim response ke perequest
        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "Lahan berhasil diajukan",
        ], 201);
    }

    public function getPlant(Request $request)
    {
        $plant = Planting::whereLand_id($request->land)->join("plants", "plants.id", "=", "plantings.plant_id")
                    ->orderByDesc("planting")->get();

        $data = [];

        foreach ($plant as $key => $value) {
            $awal  = strtotime($value->planting);
            $akhir = time();
            $masa  = $akhir - $awal;
            $birth = floor($masa / (60 * 60 * 24));

            $new = [
                "id" =>  $value->id,
                "name" => $value->name,
                "planting" => $value->planting,
                "status" => $value->status,
                "birth" => $birth
            ];
            array_push($data, $new);
        }

        // Mengirim response ke perequest
        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "get plant data successfully",
            "amount" => count($data),
            "data" => $data
        ], 202);
    }
    
    public function addPlant(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            'plant' => 'required|string|exists:plants,name',
            'planting' => 'required|string',
            'land' => 'required',
        ]);

        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed input format",
                "detail" => $validator->errors(),
            ], 401);
        }

        $plant = Plant::whereName($request->plant)->first()->id;

        // Menyimpan data lahan ke DB
        Planting::create([
            'plant_id' => $plant,
            'land_id' => $request->land,
            'planting' => $request->planting,
            'status' => true,
        ]);

        // Mengirim response ke perequest
        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "Data tanaman berhasil ditambahkan",
        ], 201);
    }

    public function addReport(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            "land" => "required|exists:lands,name",
            "sample" => "required"
        ]);

        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed input format",
                "detail" => $validator->errors(),
            ], 401);
        }

        // dd($request->all());

        $data = Report::orderBy('code')->orderByDesc('code')->value('code');
        $list = (int) substr($data, 3, 7);
        $list++;
        $code = "RLP" . sprintf("%07s", $list);
        $fileName = "img-r-" . Str::slug($code) . "." . $request->sample->extension();

        // mengambl data user login
        $user = $request->user();

        // Menyimpan data lahan ke DB
        $report = Report::create([
            'code' => $code,
            'user_id' => $user->id,
            'land_id' => Land::whereName($request->land)->value('id'),
            'sample' => $fileName,
        ]);

        // Menyimpan gambar ke server
        $request->sample->move(public_path('image/report'), $fileName);

        /* 
        * PR 
        * Buat proses pengecekan hama 
        * Langsung input ke database tabel Results
        */

        $result = Result::whereReport_code($report->code)
            ->join('pests', 'results.pest_id', '=', 'pests.id')
            ->first();

        $data = [
            "code" => $report->code,
            "date" => $report->created_at,
            "image" => "http://169.254.141.215/T-Connect/public/image/report/" . $report->sample,
            "pest_id" => $result == null ? 2 : $result->pest_id,
            "pest" => $result == null ? "nama" : $result->name,
        ];

        // Mengirim response ke perequest
        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "Data pengecekan hama berhasil diterima",
            "data" => $data
        ], 201);
    }

    public function getHistory(Request $request)
    {
        $history = [];
      
        // mengambil data history
        $report = Report::whereLand_id($request->land)
                    ->orderBy('code', 'desc')
                    ->get();

        foreach ($report as $key => $value) {
            $result = Result::whereReport_code($value->code)
                ->join('pests', 'results.pest_id', '=', 'pests.id')
                ->first();

            $data = [
                "code" => $value->code,
                "date" => $value->created_at,
                "image" => "http://169.254.141.215/T-Connect/public/image/report/" . $value->sample,
                "pest_id" => $result == null ? 2 : $result->pest_id,
                "pest" => $result == null ? "nama" : $result->name,
            ];

            array_push($history, $data);
        }

        // Mengirim response ke perequest
        return response()->json([
            "code" => 202,
            "status" => "success",
            "message" => "get history successfully",
            "amount" => count($history),
            "data" => $history
        ], 202);
    }

    public function getHandling(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            "pest_id" => "required",
        ]);

        $handle = [];

        // mengambil data penanganan
        $handling = Action::wherePest_id($request->pest_id)->get();

        $i = 1;
        foreach ($handling as $key => $isi) {
            $data = [
                "no" => $i,
                "data" => $isi->detail
            ];

            $i++;
            array_push($handle, $data);
        }

        // Mengirim response ke perequest
        return response()->json([
            "code" => 202,
            "status" => "success",
            "message" => "get handle successfully",
            "data" => $handle
        ], 202);
    }
}
