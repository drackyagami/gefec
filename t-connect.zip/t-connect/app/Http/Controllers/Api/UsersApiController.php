<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UsersApiController extends Controller
{
    public function editProfile(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            'username' => 'string',
            'email' => 'email',
            'birth' => 'string',
            'phone' => 'string',
            'avatar' => 'string',
        ]);

        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed authenticated form",
                "detail" => $validator->errors(),
            ], 401);
        }

        // Mengambil data user login
        $user = $request->user();

        // Update data alamat
        $user->username = $request->username;
        $user->email = $request->email;
        $user->birth = $request->birth;
        $user->phone = $request->phone;
        $user->avatar = $request->avatar;
        $user->save();

        // Mengirim response ke perequest
        return response()->json([
            "code" => 200,
            "status" => "success",
            "message" => "profile has updated",
        ], 200);
    }

    public function editPassword(Request $request)
    {
        // set validation
        $validator = Validator::make($request->all(), [
            'password' => 'required|string|min:8',
        ]);

        // memperbaharui password
        $user = $request->user();
        $user->password = Hash::make($request->password);
        $user->save();

        // Mengirim response ke perequest
        return response()->json([
            "code" => 201,
            "status" => "success",
            "message" => "password has updated",
        ], 201);
    }

    public function editAddress(Request $request)
    {
        //set validation
        $validator = Validator::make($request->all(), [
            'address' => 'required|string',
            'city' => 'required|string',
            'province' => 'required|string',
            'lat' => 'required|string',
            'long' => 'required|string',
        ]);

        //response error validation berdasarkan inputan
        if ($validator->fails()) {
            return response()->json([
                "code" => 401,
                "status" => "failed",
                "message" => "failed authenticated form",
                "detail" => $validator->errors(),
            ], 401);
        }

        // Mengambil data user login
        $user = $request->user();

        // Update data alamat
        $user->address = $request->address;
        $user->city = $request->city;
        $user->province = $request->province;
        $user->lat = $request->lat;
        $user->long = $request->long;
        $user->save();

        // Mengirim response ke perequest
        return response()->json([
            "code" => 200,
            "status" => "success",
            "message" => "address has updated",
        ], 200);
    }

    public function getCount(Request $request){
        $message = Notification::whereUser_id($request->user()->id)
                    ->whereType("Message")
                    ->whereStatus(true)
                    ->orderBy('id', 'desc')
                    ->count();
        
        $notif = Notification::whereUser_id($request->user()->id)
                    ->whereType("Notification")
                    ->whereStatus(true)
                    ->orderBy('id', 'desc')
                    ->count();

        return response()->json([
            "code" => 200,
            "status" => "success",
            "message" => "get count data notification successfully",
            "notif" => $notif,
            "sms" => $message
        ], 200);
    }

    public function getMessage(Request $request)
    {
        $message = Notification::whereUser_id($request->user()->id)
                    ->whereType("Message")
                    ->orderBy('id', 'desc')
                    ->get();

        // Mengirim response ke perequest
        return response()->json([
            "code" => 200,
            "status" => "success",
            "message" => "get message data successfully",
            "amount" => count($message),
            "data" => $message
        ], 200);
    }

    public function getNotify(Request $request)
    {
        $notify = Notification::whereUser_id($request->user()->id)
                    ->whereType("Notification")
                    ->orderBy('id', 'desc')
                    ->get();

        // Mengirim response ke perequest
        return response()->json([
            "code" => 200,
            "status" => "success",
            "message" => "get notify data successfully",
            "amount" => count($notify),
            "data" => $notify
        ], 200);
    }

    public function reading(Request $request)
    {
        $notify = Notification::whereUser_id($request->user()->id)
                    ->find($request->id);
                    
        $notify->status = false;
        $notify->save();

        return response()->json([
            "code" => 202,
            "status" => "success",
            "message" => "Notify has readed",
        ], 202);
    }
}
