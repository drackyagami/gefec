__API Spec Community Organizing__
---

---
__`For Mobile Aplication`__

- _`Auth`_

<!-- Login User -->

Request :
- Method : POST
- Endpoint : `/api/login`
- Header :
    - Content-Type : application/json
    - Accept : application/json
- Body :

```json
{
    "email" : "string",
    "password" : "string",
}
```

Response :

```json
{
    "code" : "number",
    "status" : "string",
    "message" : "string",
    "link" : {
        /*   ---! optional
        "profile" : "http://...../{id}"
        "community" : "http://...../communities/{id}"
        "avatar" : "http://...../avatar/{id}"
        */
    },
    "data" : {
        "id" :  "string, unique",
        "username" : "string",
        "email" : "string",
        "password" : "string",
        "created_at" : "date",
        "updated_at" : "date",
    },
    "token" : "Bearer unique token",
}
```

<!-- Register User -->

Request :
- Method : POST
- Endpoint : `/api/register`
- Header :
    - Content-Type : application/json
    - Accept : application/json
- Body :

```json
{
    "username" : "string",
    "email" : "string",
    "password" : "string",
}
```

Response :

```json
{
    "code" : "number",
    "status" : "string",
    "message" : "string",
    "link" : {
        /*   ---! optional
        "profile" : "http://...../{id}"
        "avatar" : "http://...../avatar/{id}"
        */
    },
    "data" : {
        "id" :  "string, unique",
        "username" : "string",
        "email" : "string",
        "password" : "string",
        "created_at" : "date",
        "updated_at" : "date",
    },
    "token" : "Bearer unique token",
}
```

<!-- Logout User -->

Request :
- Method : GET
- Endpoint : `/api/register`
- Header :
    - Authorization : Bearer Token
    - Content-Type : application/json
    - Accept : application/json

Response :

```json
{
    "code" : "number",
    "status" : "string",
    "message" : "string",
}
```

---

__`Global API`__

- _`Users`_
- _`Communities`_
- _`Access`_
- _`Controlls`_
- _`Information`_
- _`Schedules`_
- _`Finance Types`_
- _`Financials`_
- _`Bills`_

<!-- Get User -->

Request :
- Method : GET
- Endpoint : `/api/users`
- Header :
    - Accept : application/json

Response :

```json
{
    "code" : "number",
    "status" : "string",
    "message" : "string",
    "data" : {
        "id" :  "string, unique",
        "username" : "string",
        "email" : "string",
        "password" : "string",
        "created_at" : "date",
        "updated_at" : "date",
    },
}
```
<!-- Update User -->

Request :
- Method : PUT
- Endpoint : `/api/users/{id_user}`
- Header :
    - Content-Type : application/json
    - Accept : application/json
- Body :

```json
{
    "username" : "string",
    "email" : "string",
    "password" : "string",
}
```

Response :

```json
{
    "code" : "number",
    "status" : "string",
    "message" : "string",
    "data" : {
        "id" :  "string, unique",
        "username" : "string",
        "email" : "string",
        "password" : "string",
        "created_at" : "date",
        "updated_at" : "date",
    },
}
```

<!-- List User -->

Request :
- Method : GET
- Endpoint : `/api/users/list`
- Header :
    - Accept : application/json
- Query Param :
    - pageSize : number
    - page : number

Response:

```json
{
    "code" : "number",
    "status" : "string",
    "message" : "string",
    "data" : [
        {
            "id" :  "string, unique",
            "username" : "string",
            "email" : "string",
            "password" : "string",
            "created_at" : "date",
            "updated_at" : "date",
        },
        {
            "id" :  "string, unique",
            "username" : "string",
            "email" : "string",
            "password" : "string",
            "created_at" : "date",
            "updated_at" : "date",
        },
    ]
}
```

<!-- Delete User -->

Request :
- Method : DELETE
- Endpoint : `/api/users/{id_user}`
- Header :
    - Accept : application/json
    
Response :

```json
{
    "code" : "number",
    "status" : "string",
}
```