<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\Pest;
use App\Models\Symptom;
use Illuminate\Http\Request;

class HamaController extends Controller
{
    public function detailHama($id){
        $data = [
            'hama' => Pest::find($id),
            'solusi' => Action::where('pest_id', $id)->get(),
            'gejala' => Symptom::where('pest_id', $id)->get(),
        ];

        return view('admin.detailHama', compact('data'));
    }

    public function tambahGejala(Request $request, $id)
    {
        Symptom::create([
            'pest_id' => $id,
            'detail' => $request->detail,
        ]);
        return back()->with('message', 'Data Gejala Hama baru telah ditambahkan');
    }
    
    public function tambahTindakan(Request $request, $id)
    {
        Action::create([
            'pest_id' => $id,
            'detail' => $request->detail,
        ]);
        return back()->with('message', 'Data Tindakan Penanganan Hama baru telah ditambahkan');
    }
}
