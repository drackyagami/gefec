<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\Land;
use App\Models\Notification;
use App\Models\Pest;
use App\Models\Plant;
use App\Models\Planting;
use App\Models\Report;
use App\Models\Symptom;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class AdminController extends Controller
{
    public function index()
    {
        $data = [
            'petani' => User::where('level', 2)->get()->count(),
            'lahan' => land::all()->count(),
            'diagnosa' => Report::all()->count(),
            'pemanenan'=>Planting::whereStatus(true)->count()


        ];
        
        return view('admin.dashboard',compact('data'));
    }

    public function dataPetani()
    {
        $data = [
            'petani' => User::whereLevel('2')->paginate(5),
        ];
        return view('admin.dataPetani', compact('data'));
    }
    

    public function infoPetani()
    {
        $data = [
            'petani' => User::whereLevel('2')->get(),
            'notif' => Notification::paginate(5),
            "db" => new User(),
        ];
        return view('admin.pemberitahuanPetani', compact('data'));
    }
    public function hapuspetani($id){
        DB::table('users')->where('id',$id)->delete();
        return back();
    }

    // PR Notifikasi
    public function tambahInfo(Request $request)
    {
        $this->validate($request, [
            "title" => "required",
            "description" => "required|string",
            "type" => "required",
            "name" => "required"
        ]);

        $user_id = User::whereUsername($request->name)->first();

        Notification::create([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'user_id' => $user_id->id,
            'status' => true,
        ]);

        $token = $user_id->fcm_token;

        $url = "https://fcm.googleapis.com/fcm/send";
        $token = "$token";
        $serverKey = 'AAAAPJQrL-k:APA91bGr5qFbh35dqjtYBJza_CQeKaTyD01kDgl1Ut5TnTcpQxI-9y5lulG59txFC4Eh64Td1JNGadT5Np4LqSDRxfrNcL6CJcGfJczyQ_vonDfzVu8pj1OJ4fAye0YK9uA9TLksrtg-';
        $title = "$request->title";
        $body = "$request->description";
        $notification = array('title' => $title, 'text' => $body, 'sound' => 'default', 'badge' => '1');
        $arrayToSend = array('to' => $token, 'notification' => $notification, 'priority' => 'high');
        $json = json_encode($arrayToSend);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: key=' . $serverKey;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        //Send the request
        $response = curl_exec($ch);
        //Close request
        if ($response === FALSE) {
            die('FCM Send Error: ' . curl_error($ch));
        }

        $err = curl_error($ch);
        
        curl_close($ch);

        if ($err) {
            $pesan = $request->type === "Message" ? "Pesan" : "Notifikasi";

            return back()->with('message', "$pesan baru untuk $user_id->username gagal dikirimkan dikarenakan cURL Error #: $err");
        } else {
            $pesan = $request->type === "Message" ? "Pesan" : "Notifikasi";

            return back()->with('message', "$pesan baru untuk $user_id->username telah dikirimkan");
        }
    }

    public function hapusInfo($id)
    {
        $notif = Notification::find($id);
        Notification::destroy($id);
        return back()->with('message', "Data $notif->type berhasil dihapus");
    }

    public function dataTanaman()
    {
        $data = [
            'tanaman' => Plant::paginate(5),
        ];
        return view('admin.dataTanaman', compact('data'));
    }

    public function tambahTanaman(Request $request)
    {
        $this->validate($request, [
            "name"   => "required|unique:plants,name",
            "range"   => "required",
            "image" => "required"
        ]);

        $fileName = 'img-t-' . Str::slug($request->name) . '.' . $request->image->extension();

        Plant::create([
            'name'   => $request->name,
            'planting_time' => $request->range,
            'image'   => $fileName,
            'status' => true,
        ]);

        $request->image->move(public_path('image/plant'), $fileName);

        return back()->with('message', 'Data Tanaman baru telah ditambahkan');
    }
    //showdata tanaman
    public function showdatatanaman(Plant $plant){


        return response()->json($plant);
    }
    //show edit tanaman
    public function showedittanaman(Plant $plant){
        $data=Plant::find($plant->id);
        return view('admin.edit-datatanaman',compact('data'));
    }
    //edit data tanaman
    public function editdatatanaman(Request $request,Plant $plant){
        $img = $request->file('image');
        $request->validate([
            'name'=>'required|unique:plants,name,'.$plant->id,
            'range'=>'required',
        ]);
        if ($request->hasFile('image')) {
        $fileName = 'img-t-' . Str::slug($request->name) . '.' . $img->getClientOriginalExtension();
            Plant::find($plant->id)->update([
                'name'   => $request->name,
                'planting_time' => $request->range,
                'image'   => $fileName,
                'status' => true,
            ]);
            $img->storeAs('plant/',$fileName,'upload');
            Storage::disk('upload')->delete('plant/' . $plant->image );
        }
        

        Plant::find($plant->id)->update([
            'name'   => $request->name,
            'planting_time' => $request->range,
            'status' => true,
        ]);
      
        return redirect(route('data.tanaman'))->with(['messagge'=>'Data sudah di ubah']);
    }
    
    //hapustanaman
    public function hapustanaman($id){
        DB::table('plants')->where('id',$id)->delete();
    return back();
    }

    public function dataHama()
    {
        $data = [
            'tanaman' => Plant::all(),
            'hama' => Pest::paginate(5),
        ];

        return view('admin.dataHama', compact('data'));
    }
     //show edit hama
     public function showedithama(Pest $pest){
        $data=Pest::find($pest->id)->with('symptom','action')->first();
        // return response()->json($data);
        return view('admin.edit-datahama',compact('data'));
    }
    public function editdatahama(Request $request,Pest $pest)
    {
        $img = $request->file('image');
        $request->validate([
            'name'=>'required',
            'symptom'=>'required',
            'action'=>'required',
        ]);
        if ($request->hasFile('image')) {
            Storage::disk('upload')->delete('pest/' . $pest->image );
        $fileName = 'img-t-' . Str::slug($request->name) . '.' . $img->getClientOriginalExtension();
           $pest=tap( Pest::find($pest->id))->update([
                'name'   => $request->name,
                'image'   => $fileName,
                
            ])->first();
            $img->storeAs('pest/',$fileName,'upload');
            
            Symptom::where('pest_id',$pest->id)->update(['detail'=>$request->symptom]);
            Action::where('pest_id',$pest->id)->update(['detail'=>$request->action]);
            return redirect(route('detail.hama',$pest->id))->with(['messagge'=>'Data sudah di ubah']);
        }
        

      $pest= tap(Pest::find($pest->id))->update([
            'name'   => $request->name,
        ])->first();
        Symptom::where('pest_id',$pest->id)->update(['detail'=>$request->symptom]);
        Action::where('pest_id',$pest->id)->update(['detail'=>$request->action]);
        return redirect(route('detail.hama',$pest->id))->with(['messagge'=>'Data sudah di ubah']);
    }
    public function tambahHama(Request $request)
    {
        $this->validate($request, [
            "name"   => "required|unique:pests",
            "plant"   => "required|string|exists:plants,name",
            "image" => "required"
        ]);

        $fileName = 'img-h-' . Str::slug($request->name) . '.' . $request->image->extension();

        Pest::create([
            'name'   => $request->name,
            'plant_target' => $request->plant,
            'image'   => $fileName,
            'status' => true,
        ]);

        $request->image->move(public_path('image/pest'), $fileName);

        return back()->with('message', 'Data Hama baru telah ditambahkan');
    }
    //hapus hama
    public function hapushama($id){
        DB::table('pests')->where('id',$id)->delete();
        return back();
    }

    public function dataLaporan()
    {
        $data = [
            'tanaman' => Plant::all(),
            'petani' => new User(),
            'hama' => Pest::all(),
            'lahan' => new Land(),
            'laporan' => Report::paginate(5),
        ];

        return view('admin.dataLaporan', compact('data'));
    }

    public function tambahLaporan(Request $request)
    {
        $this->validate($request, [
            "petani" => "required|exists:users,username",
            "lahan" => "required|exists:lands,name",
            "image" => "required"
        ]);

        $data = Report::orderBy('code')->value('code');
        $list = (int) substr($data, 3, 7);
        $list++;
        $code = "rlp" . sprintf("%07s", $list);
        $fileName = "img-r-$code." . $request->image->extension();

        Report::create([
            'code'   => $code,
            'user_id' => User::whereUsername($request->petani)->value('id'),
            'land_id'   => Land::whereName($request->lahan)->value('id'),
            'sample'   => $fileName,
        ]);

        $request->image->move(public_path('image/report'), $fileName);

        return back()->with('message', 'Data Pengaduan baru telah ditambahkan');
    }

    public function detailLaporan($id)
    {
        $data = [
            'tanaman' => Plant::all(),
            'petani' => new User(),
            'hama' => Pest::all(),
            'lahan' => new Land(),
            'laporan' => Report::whereCode($id)->get(),
        ];

        return view('admin.detailLaporan', compact('data'));
    }
    public function profilepetani(){
        return view('petani.profile');
    }
    //Edit Profil
    public function editprofile(Request $request){
        // dd($request->all());
        $request->validate([
            'username'=>'required',
            'email'=>'required',
            'address'=>'required',
            'city'=>'required',
            'province'=>'required',
            'birth'=>'required'
            
        ]);
        User::find(Auth::user()->id)->update($request->all());
        return back()->with(['messagge'=>'Profile sudah di Ubah']);
    }

    public function passwordptn(){
        return view('petani.passwordptn');
    }
        //edit password
        public function editpassword(Request $request){
            $request->validate([
                'password_lama'=>'required',
                'password_baru'=>'required',
                'konfirmasi_password'=>'same:password_baru',
            ]);
    
            $check = Hash::check($request->password_lama, Auth::user()->password);
            if ($check == true) {
                
                User::find(Auth::user()->id)->update(['password'=>Hash::make($request->password_baru)]);
                return back();
            }
            return redirect('/petani/passwordptn')->with(['message' => 'Password lama Anda salah!']);
    
    
            
        }
        
}
