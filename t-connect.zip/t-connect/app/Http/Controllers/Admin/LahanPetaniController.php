<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Land;
use App\Models\Planting;
use App\Models\User;
use Illuminate\Http\Request;

class LahanPetaniController extends Controller
{
    public function dataLahan($id)
    {
        $data = [
            'petani' => User::find($id),
            'lahan' => Land::whereUser_id($id)->get(),
        
        ];
        
        return view('admin.daftarLahan', compact('data'));
    }

    public function showLahan($id, $id2){
        $data = [
            'petani' => User::find($id),
            'lahan' => Land::find($id2),
            'tanaman' => Land::whereLand_id($id2)->join("plantings", "plantings.land_id", "=", "lands.id")->get(),
            'jmltnm' => Land::whereLand_id($id2)->join("plantings", "plantings.land_id", "=", "lands.id")->get()->count(),
            'jmlpnn' => Land::whereLand_id($id2)->join("plantings", "plantings.land_id", "=", "lands.id")->where('plantings.status',true)->get()->count()
        ];

        return view('admin.detailLahan', compact('data'));
    }
}
