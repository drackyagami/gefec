<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email|exists:users,email',
            'password' => 'required|string',
        ]);

        $account = $request->only('email', 'password');

        if (Auth::attempt($account)) {
            $user = Auth::user();
            if ($user->level == '1') {
                return redirect()->intended('dashboard');
            } elseif ($user->level == '2') {
                return redirect()->intended('petani/dashboard');
            }
            return redirect()->intended('/');
        }
        return redirect('/')->with('status', 'Password yang anda masukkan salah');
    }

    public function register(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email|unique:users,email',
        ]);

        $email = $request->email;
        return view('auth.form', compact('email'));
    }
}
