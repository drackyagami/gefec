<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>T-Connect</title>

    <link rel="shortcut icon" href="{{ asset('assets/img/logo.png') }}" type="image/x-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('assets/css/auth.css') }}">
</head>

<body class="antialiased">
    <!-- Form-->
    <div class="form">
        <div class="form-toggle"></div>
        <div class="form-panel">
            <div class="form-header">
                <h1>Account Login</h1>
            </div>
            @if (session('error'))
            <div class="alert alert-danger mt-2" role="alert">
                {{ session('error') }}
            </div>
            @endif
            @if (session('status'))
            <div class="mb-4 font-medium text-sm text-green-600">
                {{ session('status') }}
            </div>
            @endif
            <div class="form-content">
                <form method="POST" action="{{ route('login') }}">
                    @csrf
                    <div class="form-group">
                        <label for="email">{{ __('Email') }}</label>
                        <input type="text" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email') }}" autocomplete="email" autofocus />
                    </div>
                    <div class="form-group">
                        <label for="password">{{ __('Password') }}</label>
                        <input type="password" class="form-control @error('password') is-invalid @enderror @if (session('status'))is-invalid @endif" id="password" name="password" autocomplete="current-password" />
                    </div>
                    <div class="form-group">
                        <label class="form-remember">
                            <input type="checkbox" id="remember" {{ old('remember') ? 'checked' : '' }} />{{ __('Remember me') }}
                        </label>
                            <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('password.request') }}">
                            {{ __('Forgot your password?') }}
                        </a>
                    </div>
                    <div class="form-group">
                        <button type="submit">{{ __('Login') }}</button>
                    </div>
                    <div class="form-group">
                        <a class="form-recovery" href="{{ route('register') }}">{{ __("Don't have an Account? Register") }}</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/core/jquery.min.js"></script>
    <script src="assets/js/auth.js">
    </script>
</body>

</html>