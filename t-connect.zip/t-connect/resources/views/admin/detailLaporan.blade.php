@extends('layouts.app')

@section('title')
Detail Laporan
@endsection

@section('data.laporan')
active
@endsection

@section('css')
<style>
    .alg {
        vertical-align: top;
    }
</style>
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Hasil Diagnosa Sampel</h4>
                <p class="card-category">Detail Hasil Diagnosa Sampel <b>{{ $data['laporan'][0]->code }}</b></p>
            </div>
            <div class="card-body">
                <div class="container">
                    <div class="row">
                        <div class="co-12 col-lg-6 col-md-12 col-sm-12">
                            <img class="rounded mx-auto img-fluid d-block my-4" src="{{ asset('image/report/'.$data['laporan'][0]->sample) }}" alt="" srcset="">
                        </div>
                        <div class="col-12 col-lg-6 col-md-12 col-sm-12">
                            <h3><b>Informasi Hasil Diagnosa</b></h3>
                            <table>
                                <tr>
                                    <td class="alg">Nama Hama</td>
                                    <td class="alg"> : </td>
                                    <td class="alg"> $data['hama']->name }} </td>
                                </tr>
                                <tr>
                                    <td class="alg" width="110">Tanaman Target</td>
                                    <td class="alg" width="10"> : </td>
                                    <td class="alg"> $data['hama']->plant_target }} </td>
                                </tr>
                                <tr>
                                    <td class="alg">Penyebab</td>
                                    <td class="alg"> : </td>
                                    <td class="alg"> $data['hama']->cause }} Jamur atogen Fusarium oxysporum f.sp cepae </td>
                                </tr>
                                <tr>
                                    <td class="alg">Detail</td>
                                    <td class="alg"> : </td>
                                    <td class="alg"> $data['hama']->detail }} Penyakit ini sering menyerang bawang merah terutama pada musim hujan, saat curah hujan tinggi dan kondisi lingkungan yang lembab. </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')

@endsection