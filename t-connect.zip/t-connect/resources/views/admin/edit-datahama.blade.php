@extends('layouts.app')

@section('title')
Edit Data hama
@endsection

@section('css')

@endsection

@section('edit.data.hama')
active
@endsection

@section('content')

<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Edit Hama</h4>
          </div>
          <div class="card-body">
            {{-- @foreach ($errors->all() as $eror)
            <div class="alert alert-danger alert-block">
              Data Harus di isi
              </div>
            
                
            @endforeach
              @if ($message = Session::get('message'))
              <div class="alert alert-danger alert-block">
                {{$message}}
              </div> 
              @endif --}}
            <form method="POST" action="{{route('edit.hama',$data->id)}}" enctype="multipart/form-data">
              @csrf
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Nama Hama</label>
                  <div class="form-group">
  
                    <input type="text" name="name"class="form-control" value="{{$data->name}}">
                  </div>
                </div>
                
                <div class="col">
                  <label class="bmd-label-floating">Gambar Hama</label>
                  <div class="form-row">
                    <div class="col">
                        <img src="{{ asset('image/pest/'.$data->image) }}" alt="" width="80">
                    </div>
                    <div class="col">
                      <input type="file" name="image"class="form-control">
                    </div>
                  </div>
                </div>
              <div class="col-md-12">
                <label class="bmd-label-floating">Gejala </label>
                <div class="form-group">

                  <textarea type="text" name="symptom"class="form-control" value=""rows="5">{{$data->symptom->detail}}</textarea>
                </div>
              </div>
            
            <div class="col-md-12 ">
                <label class="bmd-label-floating">Penanganan </label>
                <div class="form-group">

                  <textarea type="text" name="action"class="form-control" value=""rows="5">{{$data->action->detail}}</textarea>
                </div>
              </div>
            
              <input type="submit" class="btn btn-primary ml-auto" value="Update">
              <div class="clearfix"></div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

@endsection