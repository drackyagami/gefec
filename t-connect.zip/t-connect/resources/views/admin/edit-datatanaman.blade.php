@extends('layouts.app')

@section('title')
Edit Data tanaman
@endsection

@section('css')

@endsection

@section('edit.data.tanaman')
active
@endsection

@section('content')

<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Edit Tanaman</h4>
          </div>
          <div class="card-body">
            {{-- @foreach ($errors->all() as $eror)
            <div class="alert alert-danger alert-block">
              Data Harus di isi
              </div>
            
                
            @endforeach
              @if ($message = Session::get('message'))
              <div class="alert alert-danger alert-block">
                {{$message}}
              </div> 
              @endif --}}
            <form method="POST" action="{{route('edit.tanaman',$data->id)}}" enctype="multipart/form-data">
              <div class="row">
                {{csrf_field()}}
                <div class="col-md-12">
                  <label class="bmd-label-floating">Nama Tanaman</label>
                  <div class="form-group">
  
                    <input type="text" name="name"class="form-control" value="{{ $data->name }}">
                  </div>
                </div>
                <div class="col-md-12">
                  <label class="bmd-label-floating">Masa Tanaman </label>
                  <div class="form-group">
  
                    <input type="number" name="range"class="form-control" value="{{ $data->planting_time }}">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Gambar Tanaman</label>
                  <div class="form-row">
                    <div class="col">
                        <img src="{{ asset('image/plant/'.$data->image) }}" alt="" width="100">
                    </div>
                    <div class="col">
                      <input type="file" name="image"class="form-control">

                    </div>
  
                  </div>
                </div>
              </div>
              <input type="submit" class="btn btn-primary pull-right" value="Update">
              <div class="clearfix"></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

@endsection