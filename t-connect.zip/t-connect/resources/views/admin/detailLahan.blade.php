@extends('layouts.app')

@section('title')
Detail Lahan
@endsection

@section('css')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<style>
    #mapid {
        height: 100%;
    }

    .card {
        height: 520px;
        margin-bottom: 0;
    }

    .hcard {
        height: 320px;
    }
</style>
@endsection

@section('data.petani')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Detail Lahan</h4>
                <p class="card-category">Detail Lahan <b>{{ $data['lahan']->name}}</b> Milik Petani <b>{{ $data['petani']->username }}</b></p>
            </div>
            <div class="card-body">
                <div class="container">
                    <div class="row">
                        <div class="col col-md-8 hcard">
                            <div id="mapid"></div>
                        </div>
                        <div class="col col-md-4">
                            <h3><b>Komposisi Data Lahan</b></h3>
                            <table>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Nama Lahan</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">{{ $data['lahan']->name }}</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Terdaftar Sejak</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">{{ $data['lahan']->created_at }}</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Status</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    @if($data['lahan']->status == true)
                                    <td>
                                        <h6 style="text-transform: capitalize;">Dipakai</h6>
                                    </td>
                                    @else
                                    <td>
                                        <h6 style="text-transform: capitalize;">Menganggur</h6>
                                    </td>
                                    @endif
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Jumlah Tanaman</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <!-- PR -->
                                    <td>
                                        <h6 style="text-transform: capitalize;"> {{$data['jmltnm']}}</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Tanaman Dipanen</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <!-- PR -->
                                    <td>
                                        <h6 style="text-transform: capitalize;"> {{$data['jmlpnn']}} </h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Alamat Lahan</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;" style="text-decoration: none;">{{ $data['lahan']->address }}</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Kota/Kabupaten</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;" style="text-decoration: none;">{{ $data['lahan']->city }}</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Provinsi</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;" style="text-decoration: none;">{{ $data['lahan']->province }}</h6>
                                    </td>
                                </tr>
                            </table>
                        </div>

                </div>   
                
            </div>
        </div>
    </div>

</div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> No </th>
                            <th> Tanaman </th>
                            <th> Tanggal Tanam </th>
                            <th> Umur Tanaman </th>
                            <th> Status </th>
                            
                        </thead>
                        <tbody>
                            <?php
                            $no=0;?>
                            @foreach($data['tanaman'] as $list)
                            <?php
                            $no++;?>
                            <tr>
                                <td> {{ $no }} </td>
                                <td> {{ $list->name }} </td>
                                <td> {{ date('d-m-Y',strtotime($list->planting)) }} </td>
                                <td>  
                                    @php
                                        $awal  = strtotime($list->planting);
                                        $akhir = time();
                                        $masa  = $akhir - $awal;
                                        $tanam = floor($masa / (60 * 60 * 24));
                                        if ($list->status == true) {
                                            echo '-';

                                        }else{
                                        echo $tanam . " hari";

                                        }
                                    @endphp
                                </td>
                                <td>  
                                    @if($list->status == true)
                                    <span class="badge badge-success">Sudah Panen</span>
                                    @else
                                    <span class="badge badge-secondary">Belum Panen</span>
                                    @endif
                                </td>
                              
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div> 
                </div>
                </div> 
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<!-- Leaflet Plugin    -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<script>
    var latlon = {!! json_encode($data['lahan']->toArray()) !!};
    console.log(latlon);
    var mymap = L.map('mapid').setView([latlon.lat, latlon.long], 13);
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=sk.eyJ1IjoibmlkdW1pbGEiLCJhIjoiY2txYjNtOG0wMGV1bDJva2RjNnoxc3JxdyJ9.C0xjMED4KtNFHkvMof8nbg', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'your.mapbox.access.token'
    }).addTo(mymap);

    var marker = L.marker([latlon.lat, latlon.long]).addTo(mymap);
</script>
@endsection
