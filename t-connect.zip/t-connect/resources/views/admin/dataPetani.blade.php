@extends('layouts.app')

@section('title')
Data Petani
@endsection

@section('data.petani')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Petani</h4>
                <p class="card-category"> Daftar Petani terdaftar Tani Modern Connect</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="petani">
                        <thead class=" text-primary">
                            <th> No. </th>
                            <th> Nama </th>
                            <th> Email </th>
                            <th> Alamat </th>
                            <th> Kota/Kabupaten </th>
                            <th> Provinsi </th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            @foreach($data['petani'] as $key => $list)
                            <tr>
                                <td> {{ $data['petani']->firstItem() + $key }} </td>
                                <td> {{ $list->username }} </td>
                                <td> {{ $list->email }} </td>
                                <td> {{ $list->address }} </td>
                                <td> {{ $list->city }} </td>
                                <td> {{ $list->province }} </td>
                                <td>
                                    <a href="{{ route('data.lahan', $list->id) }}" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">auto_stories</i>
                                    </a>
                                   
                                    <form class="form" method="POST" action="{{ route('hapus.petani',$list->id) }}">
                                        @csrf
                                        @method('delete')
                                    <button class="btn btn-danger btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">do_not_disturb_on</i>
                                    </button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <div class="pull-right">
                    {{ $data['petani']->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
@section('script')
<script>
    $(document).ready( function () {
    $('#petani').DataTable();} 
    );
</script>
@endsection