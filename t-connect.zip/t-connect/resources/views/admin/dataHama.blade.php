@extends('layouts.app')

@section('title')
Data Hama
@endsection

@section('data.hama')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Hama</h4>
                
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> No </th>
                            <th> Nama </th>
                            <th> Tanaman </th>
                            <!-- <th> Gambar </th>
                            <th> Gejala </th>
                            <th> Tindakan </th> -->
                            
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php $key = 1; ?>
                            @foreach($data['hama'] as $key => $list)
                            <tr>
                                <td> {{ $data['hama']->firstItem() + $key }} </td>
                                <td> {{ $list->name }} </td>
                                <td> {{ $list->plant_target }} </td>
                                <!-- <td> <img src="{{ asset('image/pest/'.$list->image) }}" alt="{{ $list->image }}" style="max-height: 150px;"> </td> -->
                                <!-- <td>
                                    Oud-Turnhout
                                </td>
                                <td>
                                    Oud-Turnhout
                                </td> -->
                         
                                <td>
                                    <a href="{{ route('detail.hama', $list->id) }}" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">visibility</i>
                                    </a>
                                    
                                    <form class="form" method="POST" action="{{ route('hapus.hama',$list->id) }}">
                                        @csrf
                                        @method('delete')
                                        <button class="btn btn-danger btn-fab btn-fab-mini btn-round" onclick="return confirm('Apakah anda yakin ?')" >
                                            <i class="material-icons">delete</i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php $key++; ?>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahHama">Tambah Data Hama</button>

                <div class="pull-right">
                    {{ $data['hama']->links() }}
                </div>
            
                <!-- Modal -->
                <div class="modal fade" id="tambahHama" tabindex="-1" role="dialog" aria-labelledby="tambahHamaLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form class="form" method="POST" action="{{ route('tambah.hama') }}" enctype="multipart/form-data">
                                @csrf
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Tambah Data Hama</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">bug_report</i></div>
                                                </div>
                                                <input type="text" class="form-control" name="name" placeholder="Nama Hama/Penyakit...">
                                            </div>
                                        </div>

                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">grass</i></div>
                                                </div>
                                                <input type="text" class="form-control" name="plant" list="datalistOptions" placeholder="Nama Tanaman target...">
                                                <datalist id="datalistOptions">
                                                    @foreach($data['tanaman'] as $plant => $tanaman)
                                                    <option value="{{ $tanaman->name }}">{{ $tanaman->name }}</option>
                                                    @endforeach
                                                </datalist>
                                            </div>
                                        </div>

                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="col col-md-12">
                                                    <label for="company" class=" form-control-label">Gambar Hama</label>
                                                    <div class="input-group">
                                                        <input type="file" id="input-fa" name="image" placeholder="Pilih Gambar..." accept="image/*" class="form-control file" data-browse-on-zone-click="true">
                                                        <span class="help-block text-info">Skala Gambar harap dengan ukuran 1920x480</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan Data Hama</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection