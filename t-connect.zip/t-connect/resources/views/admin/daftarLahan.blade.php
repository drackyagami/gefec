@extends('layouts.app')

@section('title')
Data Lahan 
@endsection

@section('data.petani')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Lahan Petani</h4>
                <p class="card-category"> Daftar Lahan Petani {{ $data['petani']->username }}</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table"id="lahanadmin">
                        <thead class=" text-primary">
                            <th> ID </th>
                            <th> Nama </th>
                            <th> Alamat </th>
                            <th> Kota/Kabupaten </th>
                            <th> Provinsi </th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            @foreach($data['lahan'] as $list)
                            <tr>
                                <td> {{ $list->id }} </td>
                                <td> {{ $list->name }} </td>
                                <td> {{ $list->address }} </td>
                                <td> {{ $list->city }} </td>
                                <td> {{ $list->province }} </td>
                                <td>
                                    <a href="{{ route('lahan.petani', [$data['petani']->id, $list->id]) }}" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">visibility</i>
                                    </a>
                                  
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script>
    $(document).ready( function () {
    $('#lahanadmin').DataTable();} 
    );
</script>
@endsection