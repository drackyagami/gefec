@extends('layouts.app')

@section('title')
Dashboard Admin
@endsection

@section('dashboard')
active
@endsection

@section('content')
<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">person</i>
                </div>
                <p class="card-category">Jumlah Petani</p>
                <h3 class="card-title">{{$data['petani']}} Orang
                </h3>
            </div>
            <div class="card-footer">
                <div class="stats"> 
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">store</i>
                </div>
                <p class="card-category">Pemanenan</p>
                <h3 class="card-title">{{$data['pemanenan']}}
                </h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">info_outline</i>
                </div>
                <p class="card-category">Deteksi Hama</p>
                <h3 class="card-title">{{$data['diagnosa']}}</h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">area_chart</i>
                </div>
                <p class="card-category">Jumlah Lahan</p>
                <h3 class="card-title">{{$data['lahan']}}
                    
                </h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
