@extends('layouts.app')

@section('title')
Detail Hama
@endsection

@section('css')
<style>
    .alg {
        vertical-align: top;
    }
</style>
@endsection

@section('data.hama')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Detail Hama</h4>
                <p class="card-category">Detail Hama <b>{{ $data['hama']->name }}</b></p>
            </div>
            <div class="card-body">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-lg-6 col-md-12 col-sm-12">
                            <img class="rounded mx-auto d-block img-fluid my-4" src="{{ asset('image/pest/'.$data['hama']->image) }}" alt="" srcset="">
                        </div>
                        <div class="col-12 col-lg-6 col-md-12 col-sm-12">
                            <h3><b>Informasi Tentang Hama</b></h3>
                            <table>
                                <tr>
                                    <td class="alg">Nama Hama</td>
                                    <td class="alg"> : </td>
                                    <td class="alg"> {{ $data['hama']->name }} </td>
                                </tr>
                                <tr>
                                    <td class="alg" width="110">Tanaman Target</td>
                                    <td class="alg" width="10"> : </td>
                                    <td class="alg"> {{ $data['hama']->plant_target }} </td>
                                </tr>
                      
                                
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col col-12">
                            <table class="table mb-0">
                                <tbody>
                                    <tr>
                                        <td>Gejala</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <table>
                                                @foreach($data['gejala'] as $k => $gejala)
                                                <tr>
                                                    <td>-</td>
                                                    <td>
                                                        {{ $gejala->detail }}
                                                    </td>
                                                
                                                </tr>
                                                @endforeach
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center">
                                <button class="btn btn-primary mb-3 {{($data['gejala']->count() != 0 ? 'd-none' : '')}}" data-toggle="modal" data-target="#tambahGejala">Tambah Gejala</button>
                              
                                

                                <!-- Modal -->
                                <div class="modal fade" id="tambahGejala" tabindex="-1" role="dialog" aria-labelledby="tambahGejalaLongTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <form class="form" method="POST" action="{{ route('tambah.gejala', $data['hama']->id) }}" enctype="multipart/form-data">
                                                @csrf
                                                <div class="modal-body">
                                                    <div class="card-header">
                                                        <h4 class="description text-center text-primary">Tambah Data Gejala {{ $data['hama']->name }}</h4>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="form-group bmd-form-group">
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                    <div class="input-group-text"><i class="material-icons">assignment_late</i></div>
                                                                </div>
                                                                <textarea type="text" class="form-control" name="detail" placeholder="Gejala Hama..." rows="10"></textarea>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="modal-footer justify-content-center">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Simpan Data Tanaman</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12">
                            <table class="table mb-10">
                                <tbody>
                                    <tr>
                                        <td>Penanganan</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <table>
                                                <?php $id = 1 ?>
                                                @foreach($data['solusi'] as $key => $solusi)
                                                <tr>
                                                    
                                                    <td>
                                                        {{ $solusi->detail }}
                                                    </td>
                                                </tr>
                                                
                                                @endforeach
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center">
                                <button class="btn btn-primary mb-3 {{($data['solusi']->count() != 0 ? 'd-none' : '')}}" data-toggle="modal" data-target="#tambahTindakan">Tambah Penanganan</button>
                                

                                <!-- Modal -->
                                <div class="modal fade" id="tambahTindakan" tabindex="-1" role="dialog" aria-labelledby="tambahTindakanLongTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <form class="form" method="POST" action="{{ route('tambah.tindakan', $data['hama']->id) }}" enctype="multipart/form-data">
                                                @csrf
                                                <div class="modal-body">
                                                    <div class="card-header">
                                                        <h4 class="description text-center text-primary">Tambah Data Penanganan {{ $data['hama']->name }}</h4>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="form-group bmd-form-group">
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                    <div class="input-group-text"><i class="material-icons">assignment</i></div>
                                                                </div>
                                                                <textarea name="detail" class="form-control" placeholder="Penanganan Hama..."></textarea>
                                                                <!-- <input type="text" class="form-control" name="detail" placeholder="Penanganan Hama..."> -->
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="modal-footer justify-content-center">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Simpan Data Tanaman</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- <div class="mx-auto text-center">
                        <a class="btn btn-primary mb-3 text-center" href="{{ route('show.hama',$data['hama']->id) }}" >Edit Data Hama</a>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')

@endsection