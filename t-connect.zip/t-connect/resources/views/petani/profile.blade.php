@extends('layouts.app')

@section('title')
Edit Profile
@endsection

@section('css')

@endsection
@section('data.profilepetani')
active
@endsection

@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Edit Profile</h4>
          
        </div>
        <div class="card-body">
          @foreach ($errors->all() as $eror)
          <div class="alert alert-danger alert-block">
            Data Harus di isi
            </div>
          
              
          @endforeach
            @if ($message = Session::get('message'))
            <div class="alert alert-danger alert-block">
              {{$message}}
            </div> 
            @endif
          <form method="POST" action="{{route('edit.petani.profile')}}">
            <div class="row">
              {{csrf_field()}}
              <div class="col-md-12">
                <label class="bmd-label-floating">Username</label>
                <div class="form-group">

                  <input type="text" name="username"class="form-control" value="{{ Auth::user()->username }}">
                </div>
              </div>
              <div class="col-md-12">
                <label class="bmd-label-floating">Email </label>
                <div class="form-group">

                  <input type="email" name="email"class="form-control" value="{{ Auth::user()->email }}">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <label class="bmd-label-floating">Alamat</label>
                <div class="form-group">

                  <input type="text" name="address"class="form-control" value="{{ Auth::user()->address }}">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <label class="bmd-label-floating">Kota</label>
                <div class="form-group">

                  <input type="text" name="city"class="form-control" value="{{ Auth::user()->city }}">
                </div>
              </div>
              <div class="col-md-6">
                <label class="bmd-label-floating">Provinsi</label>
                <div class="form-group">

                  <input type="text" name="province"class="form-control" value="{{ Auth::user()->province }}">
                </div>
              </div>

              <div class="col-md-12">
                <label class="bmd-label-floating">Tanggal Lahir</label>
                <div class="form-group">
                  <input type="date" name ="birth" class="form-control" value="{{ Auth::user()->birth }}">
                </div>
              </div>
            </div>

            <button type="submit" class="btn btn-primary pull-right">Update Profile</button>
            <div class="clearfix"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection