@extends('layouts.app')

@section('title')
Data Tanaman
@endsection

@section('css')

@endsection

@section('data.tanaman')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Tanaman</h4>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="tanaman">
                        <thead class=" text-primary">
                            <th> ID </th>
                            <th> Nama Lahan </th>
                            <th> Nama Tanaman </th>
                            <th> Tanggal tanam</th>
                            <th> Umur Tanaman </th>
                            <th> Masa Tanam </th>
                            <th> Status Tanaman </th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            @foreach($data['lahan'] as $key => $list)
                            <tr>
                                <td> {{ $key + 1 }} </td>
                                <td> {{ $list->name }} </td>
                                @php
                                    $tanaman = $data['plant']::whereId($list->plant_id)->first();
                                @endphp
                                <td> {{ $tanaman['name'] }} </td>
                                <td> {{ date('d-m-Y',strtotime($list->planting)) }}
                                 </td>
                                 @if ($list->status === true)
                                    @php
                                        $awal = $list->planting;
                                        $akhir = $list->updated_at;

                                        $selisih = \Carbon\Carbon::parse($awal)->diffInDays($akhir)
                                    @endphp
                                 <td>{{$selisih}} Hari</td>
                                 @else
                                 <td> 
                                     @php
                                         $awal  = strtotime($list->planting);
                                         $akhir = time();
                                         $masa  = $akhir - $awal;
                                         $tanam = floor($masa / (60 * 60 * 24));
 
                                         echo $tanam . " hari";
 
                                         
                                     @endphp
                                 </td>
                                     
                                 @endif
                                <td> {{ $tanaman['planting_time'] }} hari </td>
                                <td>
                                   
                                    @if($list->status == true)
                                    <span class="badge badge-success">Sudah Panen</span>
                                    @else
                                    <span class="badge badge-secondary">Belum Panen</span>
                                    @endif
                                    
                                </td>
                                <td>
                                    <form class="form" method="POST" action="{{route('ganti.petani.status',$list->id)}}">
                                    @csrf
                                    {{-- <input name="status" class="btn btn-primary btn-fab btn-fab-mini btn-round" type="submit"> --}}
                                    <button name="status" type="submit" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">local_florist</i>
                                    </button>
                                    </form>
                                    
                                        <form class="form" method="POST" action="{{ route('hapus.petani.tanaman',$list->id) }}">
                                        @csrf
                                        @method('delete')
                                        <button class="btn btn-danger btn-fab btn-fab-mini btn-round" onclick="return confirm('Apakah anda yakin ?')" >
                                            <i class="material-icons">delete</i>
                                
                                </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">Tambah Data Tanaman</button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form class="form" method="POST" action="{{ route('tambah.petani.tanaman') }}">
                                @csrf
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Tambah Data Tanaman</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">pin_drop</i></div>
                                                </div>
                                                <select class="form-control" name="land" required>
                                                    <option disabled selected hidden>Pilih Lahan....</option>
                                                    @foreach($data['land'] as $key => $land)
                                                        <option value="{{ $land->id }}">[LID{{ $land->id }}] {{ $land->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">grass</i></div>
                                                </div>
                                                <select class="form-control" name="plant" required>
                                                    <option disabled selected hidden>Pilih Tanaman....</option>
                                                    @php 
                                                        $tanaman = $data['plant']::all();
                                                    @endphp
                                                    @foreach($tanaman as $id => $tanaman)
                                                        <option value="{{ $tanaman->id }}">[PID{{ $tanaman->id }}] {{ $tanaman->name }}</option>
                                                    @endforeach
                                                </select>
                                                {{-- </div> --}}
                                            </div>
                                        </div>

                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">date_range</i></div>
                                                </div>
                                                <input type="date" class="form-control" name="date" max="{{ Carbon\Carbon::now()->toDateString() }}" placeholder="Masa Tanam Tanaman..." required>
                                            </div>
                                        </div>

                                        {{-- <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="col col-md-12">
                                                    <label for="company" class=" form-control-label">Gambar Tanaman</label>
                                                    <div class="input-group">
                                                        <input type="file" id="input-fa" name="image" placeholder="Pilih Gambar..." accept="image/*" class="form-control file" data-browse-on-zone-click="true">
                                                        <span class="help-block text-info">Skala Gambar harap dengan ukuran 1920x480</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> --}}

                                    </div>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan Data Tanaman</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
    $(document).ready( function () {
    $('#tanaman').DataTable();} 
    );

</script>
@endsection