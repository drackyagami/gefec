@extends('layouts.app')

@section('title')
Edit Data Lahan
@endsection

@section('css')

@endsection

@section('data.lahan')
active
@endsection

@section('content')

<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Edit lahan</h4>
          </div>
          <div class="card-body">
            @foreach ($errors->all() as $eror)
            <div class="alert alert-danger alert-block">
              Data Harus di isi
              </div>
            
                
            @endforeach
              @if ($message = Session::get('message'))
              <div class="alert alert-danger alert-block">
                {{$message}}
              </div> 
              @endif
            <form method="POST" action="/petani/updatelahan/{{$lahan->id}}">
              <div class="row">
                {{csrf_field()}}
                <div class="col-md-12">
                  <label class="bmd-label-floating">Nama Lahan</label>
                  <div class="form-group">
  
                    <input type="text" required name="name"class="form-control" value="{{ $lahan->name }}">
                  </div>
                </div>
                <div class="col-md-12">
                  <label class="bmd-label-floating">Longitude </label>
                  <div class="form-group">
  
                    <input type="text" required name="long"class="form-control" value="{{ $lahan->long }}">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Langitude</label>
                  <div class="form-group">
  
                    <input type="text" required name="lat"class="form-control" value="{{ $lahan->lat }}">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <label class="bmd-label-floating">Luas Lahan</label>
                  <div class="form-group">
  
                    <input type="text" required name="large"class="form-control" value="{{ $lahan->large }}">
                  </div>
                </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Alamat Lahan</label>
                  <div class="form-group">
  
                    <input type="text" required name="address"class="form-control" value="{{ $lahan->address }}">
                  </div>
                </div>
              </div>
                <div class="col-md-6">
                  <label class="bmd-label-floating">Kabupaten/kota</label>
                  <div class="form-group">
  
                    <input type="text"  required name="city"class="form-control" value="{{$lahan->city}}">
                  </div>
                </div>
  
                <div class="col-md-6">
                  <label class="bmd-label-floating">Provinsi</label>
                  <div class="form-group">
                    <input type="text" required name ="province" class="form-control" value="{{ $lahan->province }}">
                  </div>
                </div>
              </div>
  
              <input type="submit" class="btn btn-primary pull-right" value="Update">
              <div class="clearfix"></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

@endsection