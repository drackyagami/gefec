@extends('layouts.app')

@section('title')
Ganti Password
@endsection

@section('css')

@endsection
@section('data.passwordptn')
active
@endsection


@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Ganti Password</h4>
        </div>
        <div class="card-body">
          <form method="POST" action="{{route('edit.petani.editpassword')}}">
            {{csrf_field()}}
            @foreach ($errors->all() as $eror)
            <div class="alert alert-danger alert-block">
              Password baru dan konfirmasi password harus sama
              </div>
            
                
            @endforeach
            @if ($message = Session::get('message'))
              <div class="alert alert-danger alert-block">
                {{$message}}
              </div>    
            @endif
            <div class="row">
              <div class="col-md-12">
                <label class="bmd-label-floating">Passowrd Lama</label>
                <div class="form-group">

                  <input type="password"name="password_lama" class="form-control">
                </div>
              </div>
              <div class="col-md-12">
                <label class="bmd-label-floating">Password Baru </label>
                <div class="form-group">

                  <input type="password" name="password_baru"class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <label class="bmd-label-floating">Konfirmasi Password Baru</label>
                <div class="form-group">

                  <input type="password"name="konfirmasi_password" class="form-control">
                </div>
              </div>
            </div>


            <button type="submit" class="btn btn-primary pull-right">Ganti Password</button>
            <div class="clearfix"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


@endsection