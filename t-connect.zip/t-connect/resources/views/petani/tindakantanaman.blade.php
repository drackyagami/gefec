@extends('layouts.app')

@section('title')
Tindakan
@endsection

@section('css')

@endsection

@section('data.tindakantanaman')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Tanaman</h4>
                
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> ID </th>
                            <th> Nama Tanaman </th>
                            <th> Nama Lahan </th>
                            <th> Waktu Tanam </th>
                            <th> Masa Tanam </th>
                            <th> Status Tanaman </th>
                            <!-- <th>
                                Informasi Lebih
                            </th> -->
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            {{-- @foreach($data['tanaman'] as $list)
                            <tr>
                                <td> {{ $list->id }} </td>
                                <td> {{ $list->name }} </td>
                                <td> <img src="{{ asset('image/plant/'.$list->image) }}" alt="{{ $list->image }}" style="max-height: 150px;"> </td>
                                <td> {{ $list->planting_time }} </td>
                                <td>
                                    @if($list->status == 0)
                                    <span class="badge badge-secondary">Not Active</span>
                                    @else
                                    <span class="badge badge-success">Active</span>
                                    @endif
                                </td>
                                <!-- <td>
                                    Oud-Turnhout
                                </td> -->
                                <td>
                                    <button class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">edit</i>
                                    </button>
                                </td>
                            </tr>
                            @endforeach --}}
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">Tambah Data Tanaman</button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form class="form" method="POST" action="{{ route('tambah.tanaman') }}" enctype="multipart/form-data">
                                @csrf
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Tambah Data Tanaman</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">grass</i></div>
                                                </div>
                                                {{-- <input type="select" class="form-control" name="name" placeholder="Nama Lahan..."> --}}
                                                {{-- <div class="form-group"> --}}
                                                    {{-- <label for="exampleFormControlSelect1"></label> --}}
                                                    <select class="form-control" id="exampleFormControlSelect1"  >
                                                      <option disabled selected hidden>Pilih Tanaman....</option>
                                                      <option>1</option>
                                                      <option>2</option>
                                                      <option>3</option>
                                                      <option>4</option>
                                                      <option>5</option>
                                                    </select>
                                                  {{-- </div> --}}
                                            </div>
                                        </div>
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">pin_drop</i></div>
                                                </div>
                                                {{-- <input type="select" class="form-control" name="name" placeholder="Nama Lahan..."> --}}
                                                {{-- <div class="form-group"> --}}
                                                    {{-- <label for="exampleFormControlSelect1"></label> --}}
                                                    <select class="form-control" id="exampleFormControlSelect1"  >
                                                      <option disabled selected hidden>Pilih Lahan....</option>
                                                      <option>1</option>
                                                      <option>2</option>
                                                      <option>3</option>
                                                      <option>4</option>
                                                      <option>5</option>
                                                    </select>
                                                  {{-- </div> --}}
                                            </div>
                                        </div>

                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">date_range</i></div>
                                                </div>
                                                <input type="date" class="form-control" name="range" placeholder="Masa Tanam Tanaman...">
                                            </div>
                                        </div>

                                        {{-- <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="col col-md-12">
                                                    <label for="company" class=" form-control-label">Gambar Tanaman</label>
                                                    <div class="input-group">
                                                        <input type="file" id="input-fa" name="image" placeholder="Pilih Gambar..." accept="image/*" class="form-control file" data-browse-on-zone-click="true">
                                                        <span class="help-block text-info">Skala Gambar harap dengan ukuran 1920x480</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> --}}

                                    </div>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan Data Tanaman</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')

@endsection