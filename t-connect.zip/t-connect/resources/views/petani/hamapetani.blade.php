@extends('layouts.app')

@section('title')
Data Hama
@endsection

@section('data.hama')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Hama</h4>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>Kode </th>
                            <th>Lahan</th>
                            <th>Tanaman </th>
                            <th>Jenis Hama</th>
                            <th>Diagnosis</th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            @foreach($data['report'] as $list)
                            <tr>
                                <td> {{ $list['code'] }} </td>
                                @php
                                    $land = $data['lahan']::find($list['land_id']);
                                @endphp
                                <td> {{ $land->name }} </td>
                                @php
                                    $plant = $data['plant']::find($land->plant_id);
                                @endphp
                                <td> {{ $plant->name }} </td>
                                @php
                                    $result = $data['result']::whereReport_code($list['code'])->first();;
                                    $hama = $result == null ? "" : $data['pest']::find($result['pest_id']);
                                @endphp
                                <td> {{ $hama == null ? "" : $hama->name }} </td>
                                <td>
                                    <img class="rounded img-fluid d-block my-4" src="{{ asset('image/report/'.$list['sample']) }}" style="height: 100px !important;">
                                </td>
                                <td>
                                    <a href="" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">visibility</i>
                                    </a>
                                    <button class="btn btn-warning btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">edit</i>
                                    </button>
                                </td>
                            </tr>

                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection