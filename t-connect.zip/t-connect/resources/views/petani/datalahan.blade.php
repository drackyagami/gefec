@extends('layouts.app')

@section('title')
Data Lahan
@endsection

@section('css')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<style>
    #mapid {
        height: 100%;
    }

    .cards {
        height: 520px;
        margin-bottom: 0;
    }

    .hcard {
        height: 210px;
    }
</style>
@endsection

@section('data.lahan')
active
@endsection

@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            {{ session('message') }}
        </div>
        @endif
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Lahan</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="lahan">
                        <thead class=" text-primary">
                            <th> No </th>
                            <th> Nama Lahan </th>
                            <th> Koordinat </th>
                            <th> Alamat </th>
                            <th> Daerah </th>
                            <th> Luas Lahan </th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php
                            $no=0;?>
                            @foreach($data['lahan'] as $key => $list)
                            <?php
                            $no++;?>
                            <tr>
                                <td> {{ $no }} </td>
                                <td> {{ $list->name }} </td>
                                <td> {{ $list->long }}, {{ $list->lat }} </td>
                                <td> {{ $list->address }} </td>
                                <td> {{ $list->city }} - {{ $list->province}} </td>
                                <td> {{ $list->large }} M<sup>2</sup></td>
                                <td>
                                    
                                        <form class="form" method="POST" action="{{ route('hapus.petani.lahan',$list->id) }}">
                                            <a href="/petani/datalahan/{{$list->id}}/edit" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                                <i class="material-icons">edit</i></a>
                                            @csrf
                                            @method('delete')
                                        <button class="btn btn-danger btn-fab btn-fab-mini btn-round" onclick="return confirm('Apakah anda yakin ?')" >
                                            <i class="material-icons">delete</i>
                                        </button>
                                        </form>
                                </td>
                                {{-- <td><button class="btn btn-danger btn-fab btn-fab-mini btn-round">
                                    <i class="material-icons">delete</i>
                                </td> --}}
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">Tambah Data Lahan</button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form class="form" method="POST" action="{{ route('tambah.petani.lahan') }}">
                                @csrf
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Tambah Data Lahan</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">grass</i></div>
                                                            </div>
                                                            <input type="text" class="form-control" name="name" placeholder="Nama Lahan..." required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">place</i></div>
                                                            </div>
                                                            <input type="text" class="form-control" name="long" id='long' placeholder="Longitude..." required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">room</i></div>
                                                            </div>
                                                            <input type="text" class="form-control" name="lat" id='lat' placeholder="Latitude..." required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">
                                                                        <span class="material-icons-outlined">
                                                                            straighten
                                                                        </span></i>
                                                                </div>
                                                            </div>
                                                            <input type="number" class="form-control" name="large" placeholder="Luas Lahan..." required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="form-group bmd-form-group hcard">
                                                        <div id="mapid"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">
                                                                        <span class="material-icons-outlined">
                                                                            straighten
                                                                        </span></i>
                                                                </div>
                                                            </div>
                                                            <input type="text" class="form-control" name="address" placeholder="Alamat Lahan..." required>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col col-md-6 col-sm-12">
                                                            <div class="form-group bmd-form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <div class="input-group-text">
                                                                            <i class="material-icons">
                                                                                <span class="material-icons-outlined">
                                                                                    straighten
                                                                                </span>
                                                                            </i>
                                                                        </div>
                                                                    </div>
                                                                    <input type="text" class="form-control" name="city" placeholder="Kabupaten/Kota..." required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col col-md-6 col-sm-12">
                                                            <div class="form-group bmd-form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <div class="input-group-text">
                                                                            <i class="material-icons">
                                                                                <span class="material-icons-outlined">
                                                                                    straighten
                                                                                </span>
                                                                            </i>
                                                                        </div>
                                                                    </div>
                                                                    <input type="text" class="form-control" name="province" placeholder="Provinsi..." required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan Data Lahan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                {{-- edit data lahan --}}
                {{-- <div class="modal fade" id="editdatalahan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form >
                                @csrf
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Edit Data Lahan</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">grass</i></div>
                                                            </div>
                                                            <input type="text" class="form-control" name="name" placeholder="Nama Lahan..." required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">place</i></div>
                                                            </div>
                                                            <input type="text" class="form-control" name="long" id='long' placeholder="Longitude..." required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">room</i></div>
                                                            </div>
                                                            <input type="text" class="form-control" name="lat" id='lat' placeholder="Latitude..." required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">
                                                                        <span class="material-icons-outlined">
                                                                            straighten
                                                                        </span></i>
                                                                </div>
                                                            </div>
                                                            <input type="number" class="form-control" name="large" placeholder="Luas Lahan..." required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="form-group bmd-form-group hcard">
                                                        <div id="mapid"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">
                                                                        <span class="material-icons-outlined">
                                                                            straighten
                                                                        </span></i>
                                                                </div>
                                                            </div>
                                                            <input type="text" class="form-control" name="address" placeholder="Alamat Lahan..." required>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col col-md-6 col-sm-12">
                                                            <div class="form-group bmd-form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <div class="input-group-text">
                                                                            <i class="material-icons">
                                                                                <span class="material-icons-outlined">
                                                                                    straighten
                                                                                </span>
                                                                            </i>
                                                                        </div>
                                                                    </div>
                                                                    <input type="text" class="form-control" name="city" placeholder="Kabupaten/Kota..." required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col col-md-6 col-sm-12">
                                                            <div class="form-group bmd-form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <div class="input-group-text">
                                                                            <i class="material-icons">
                                                                                <span class="material-icons-outlined">
                                                                                    straighten
                                                                                </span>
                                                                            </i>
                                                                        </div>
                                                                    </div>
                                                                    <input type="text" class="form-control" name="province" placeholder="Provinsi..." required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> --}}
{{-- 
                                </div>
                                
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Edit Data Lahan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> --}}

        </div>
    </div>
</div>
@endsection

@section('script')
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<script>
    var map, newMarker, markerLocation;
  
    $(function() {
        navigator.geolocation.getCurrentPosition(position => {
   var { longitude, latitude } = position.coords;
  // Show a map centered at latitude / longitude.
  console.log(longitude +" "+  latitude) 
  // Initialize the map
  var map = L.map('mapid').setView([latitude, longitude],20);
        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=sk.eyJ1IjoibmlkdW1pbGEiLCJhIjoiY2txYjNtOG0wMGV1bDJva2RjNnoxc3JxdyJ9.C0xjMED4KtNFHkvMof8nbg', {
            center:[latitude, longitude],
            zoom: 10,
            id: 'mapbox/streets-v11',
            tileSize: 512,
            zoomOffset: -1,
        }).addTo(map);
        newMarkerGroup = new L.LayerGroup();
        map.on('click', addMarker);
    }); 
});
        

    function addMarker(e) {
        // Add marker to map at click location; add popup window
        // console.log(e.latlng.lat);
        document.getElementById('long').value = e.latlng.lng;
        document.getElementById('lat').value = e.latlng.lat;
        var newMarker = new L.marker([e.latlng.lat, e.latlng.lng]).addTo(map);
    }
    $(document).ready( function () {
    $('#lahan').DataTable();
} );
</script>
@endsection