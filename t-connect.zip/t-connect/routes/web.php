<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

require __DIR__ . '/auth.php';

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::post('/login', [App\Http\Controllers\Auth\AuthController::class, 'login'])->name('login');

Route::group(['middleware' => ['auth']], function () {
    Route::group(['middleware' => ['filter:1']], function () {
        Route::get('/dashboard', [App\Http\Controllers\Admin\AdminController::class, 'index'])->name('dashboard');
        Route::get('/data/petani', [App\Http\Controllers\Admin\AdminController::class, 'dataPetani'])->name('data.petani');
        Route::get('/data/petani/{id}', [App\Http\Controllers\Admin\LahanPetaniController::class, 'dataLahan'])->name('data.lahan');
        Route::get('/data/petani/{id}/lahan/{id2}', [App\Http\Controllers\Admin\LahanPetaniController::class, 'showLahan'])->name('lahan.petani');
        Route::delete('/data/petani/{id}', [App\Http\Controllers\Admin\AdminController::class, 'hapuspetani'])->name('hapus.petani');

        Route::get('/data/tanaman', [App\Http\Controllers\Admin\AdminController::class, 'dataTanaman'])->name('data.tanaman');
        Route::post('/data/tanaman', [App\Http\Controllers\Admin\AdminController::class, 'tambahTanaman'])->name('tambah.tanaman');
        Route::delete('/data/tanaman/{id}', [App\Http\Controllers\Admin\AdminController::class, 'hapustanaman'])->name('hapus.tanaman');
        Route::get('/data/tanaman/edit/{plant}', [App\Http\Controllers\Admin\AdminController::class, 'showedittanaman'])->name('show.edit.tanaman');
        Route::post('/data/tanaman/edit/{plant}', [App\Http\Controllers\Admin\AdminController::class, 'editdatatanaman'])->name('edit.tanaman');
        

        Route::get('/data/hama', [App\Http\Controllers\Admin\AdminController::class, 'dataHama'])->name('data.hama');
        Route::get('/data/hama/{id}', [App\Http\Controllers\Admin\HamaController::class, 'detailHama'])->name('detail.hama');
        Route::post('/data/hama/{id}/gejala', [App\Http\Controllers\Admin\HamaController::class, 'tambahGejala'])->name('tambah.gejala');
        Route::post('/data/hama/{id}/tindakan', [App\Http\Controllers\Admin\HamaController::class, 'tambahTindakan'])->name('tambah.tindakan');
        Route::post('/data/hama', [App\Http\Controllers\Admin\AdminController::class, 'tambahHama'])->name('tambah.hama');
        Route::delete('/data/hama/{id}', [App\Http\Controllers\Admin\AdminController::class, 'hapushama'])->name('hapus.hama');
        Route::get('/data/hama/edit/{pest}', [App\Http\Controllers\Admin\AdminController::class, 'showedithama'])->name('show.hama');
        Route::post('/data/hama/edit/{pest}', [App\Http\Controllers\Admin\AdminController::class, 'editdatahama'])->name('edit.hama');
        
        Route::get('/info/petani', [App\Http\Controllers\Admin\AdminController::class, 'infoPetani'])->name('info.petani');
        Route::post('/info/petani', [App\Http\Controllers\Admin\AdminController::class, 'tambahInfo'])->name('tambah.info');
        Route::delete('/info/petani/{id}', [App\Http\Controllers\Admin\AdminController::class, 'hapusInfo'])->name('hapus.info');
        
        Route::get('/data/laporan', [App\Http\Controllers\Admin\AdminController::class, 'dataLaporan'])->name('data.laporan');
        Route::post('/data/laporan', [App\Http\Controllers\Admin\AdminController::class, 'tambahLaporan'])->name('tambah.laporan');
        Route::get('/data/laporan/{id}', [App\Http\Controllers\Admin\AdminController::class, 'detailLaporan'])->name('detail.laporan');
    });
    Route::group(['middleware' => ['filter:2']], function () {
        Route::get('/petani/dashboard', [App\Http\Controllers\Petani\PetaniController::class, 'index'])->name('dashboard');
        
        Route::get('/petani/datatanaman', [App\Http\Controllers\Petani\PetaniController::class, 'dtanaman'])->name('data.petani.tanaman');
        Route::post('/petani/datatanaman', [App\Http\Controllers\Petani\PetaniController::class, 'addtanaman'])->name('tambah.petani.tanaman');
        Route::delete('/petani/datatanaman/{id}', [App\Http\Controllers\Petani\PetaniController::class, 'hapustanaman'])->name('hapus.petani.tanaman');
        Route::post('/petani/datatanaman/{id}', [App\Http\Controllers\Petani\PetaniController::class, 'gantipanen'])->name('ganti.petani.status');

        Route::get('/petani/hamapetani', [App\Http\Controllers\Petani\PetaniController::class, 'dhama'])->name('data.petani.hama');
        Route::post('/petani/hamapetani', [App\Http\Controllers\Petani\PetaniController::class, 'addhama'])->name('tambah.petani.hama');

        Route::get('/petani/datalahan', [App\Http\Controllers\Petani\PetaniController::class, 'dlahan'])->name('data.petani.lahan');
        Route::delete('/petani/datalahan/{id}', [App\Http\Controllers\Petani\PetaniController::class, 'deletelahan'])->name('hapus.petani.lahan');
        Route::post('/petani/datalahan', [App\Http\Controllers\Petani\PetaniController::class, 'addlahan'])->name('tambah.petani.lahan');
        Route::put('/petani/datalahan/{id}', [App\Http\Controllers\Petani\PetaniController::class, 'editlahan'])->name('edit.petani.lahan');
        Route::get('/petani/datalahan/{id}/edit', [App\Http\Controllers\Petani\PetaniController::class, 'edit_lahan'])->name('editdata.petani.lahan');
        Route::post('/petani/updatelahan/{id}', [App\Http\Controllers\Petani\PetaniController::class, 'update_lahan']);

        Route::get('/petani/kondisitanaman', [App\Http\Controllers\Petani\PetaniController::class, 'ktanaman'])->name('data.petani.kondisi');
        Route::get('/petani/tindakan', [App\Http\Controllers\Petani\PetaniController::class, 'ttanaman'])->name('data.petani.tindakan');
        Route::get('/petani/perangkat', [App\Http\Controllers\Petani\PetaniController::class, 'perangkattnm'])->name('data.petani.perangkattnm');
        Route::get('/petani/proflie', [App\Http\Controllers\Petani\PetaniController::class, 'profilepetani'])->name('data.petani.profile');
        Route::post('/petani/proflie', [App\Http\Controllers\Petani\PetaniController::class, 'editprofile'])->name('edit.petani.profile');
        Route::get('/petani/passwordptn', [App\Http\Controllers\Petani\PetaniController::class, 'passwordptn'])->name('data.petani.passwordptn');
        Route::post('/petani/passwordptn', [App\Http\Controllers\Petani\PetaniController::class, 'editpassword'])->name('edit.petani.editpassword');
    });
});
