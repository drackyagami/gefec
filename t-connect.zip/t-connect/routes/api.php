<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UsersApiController;
use App\Http\Controllers\Api\AuthApiController;
use App\Http\Controllers\Api\LahanApiController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/users', [ApiController::class, 'userList']);

Route::group(['middleware' => 'auth:sanctum'], function () {
    Route::put('/send-fcm', [AuthApiController::class, 'fcm']);
    Route::put('/update-password', [UsersApiController::class, 'editPassword']);
    Route::patch('/update-profile', [UsersApiController::class, 'editProfile']);
    Route::patch('/update-address', [UsersApiController::class, 'editAddress']);

    Route::get('/lahan', [LahanApiController::class, 'getLand']);
    Route::post('/lahan', [LahanApiController::class, 'addLand']);
    
    Route::get('/plant', [LahanApiController::class, 'getPlant']);
    Route::post('/plant', [LahanApiController::class, 'addPlant']);
    
    Route::get('/message', [UsersApiController::class, 'getMessage']);
    Route::get('/notify', [UsersApiController::class, 'getNotify']);
    Route::get('/count', [UsersApiController::class, 'getCount']);
    Route::put('/reading', [UsersApiController::class, 'reading']);
    
    Route::post('/report', [LahanApiController::class, 'addReport']);
    Route::get('/history', [LahanApiController::class, 'getHistory']);
    Route::post('/handling', [LahanApiController::class, 'getHandling']);

    Route::put('/password', [AuthApiController::class, 'password']);
    Route::post('/logout', [AuthApiController::class, 'logout']);
});

Route::post('/login', [AuthApiController::class, 'login']);
Route::post('/register', [AuthApiController::class, 'register']);
Route::post('/forgot', [AuthApiController::class, 'forgot']);
