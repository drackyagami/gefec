<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        $user = [
            [                
                'username'  => 'T-Connect',
                'email'     => 'hifni11alimudin@gmail.com',
                'password'  => Hash::make('Sandinya_01'),
                // 'birth'     => 11-03-2000,
                'address'   => 'Politeknik Negeri Indramayu',
                'city'      => 'Indramayu',
                'province'  => 'Jawa Barat',
                'phone'     => '087828626806',
                'level'     => '1',
                'status'    => true,
                'created_at'=> now(),
                'updated_at'=> now(),
            ],
            [
                'username'  => 'Nidumila',
                'email'     => 'portomila.port@gmail.com',
                'password'  => Hash::make('Sandinya_01'),
                // 'birth'     => 11-03-2000,
                'address'   => 'Politeknik Negeri Indramayu',
                'city'      => 'Indramayu',
                'province'  => 'Jawa Barat',
                'phone'     => '087828626806',
                'level'     => '2',
                'status'    => true,
                'created_at'=> now(),
                'updated_at'=> now(),
            ],
        ];

        foreach ($user as $key => $value) {
            User::create($value);
        }
    }
}
