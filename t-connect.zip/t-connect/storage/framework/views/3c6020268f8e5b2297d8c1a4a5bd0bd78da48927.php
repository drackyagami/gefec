

<?php $__env->startSection('title'); ?>
Data Tanaman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.tanaman'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Tanaman</h4>
                <p class="card-category">Tanaman terdaftar Tani Modern Connect</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> ID </th>
                            <th> Nama </th>
                            <th> Gambar </th>
                            <th> Masa Tanam </th>
                            
                            <!-- <th>
                                Informasi Lebih
                            </th> -->
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['tanaman']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($data['tanaman']->firstItem() + $key); ?> </td>
                                <td> <?php echo e($list->name); ?> </td>
                                <td> <img src="<?php echo e(asset('image/plant/'.$list->image)); ?>" alt="<?php echo e($list->image); ?>" style="max-height: 150px;"> </td>
                                <td> <?php echo e($list->planting_time); ?> Hari</td>

                                <!-- <td>
                                    Oud-Turnhout
                                </td> -->
                                <td>
                                    <a class="btn btn-primary btn-fab btn-fab-mini btn-round btnEditTanaman"href="<?php echo e(route('show.edit.tanaman',$list->id)); ?>" >
                                        <i class="material-icons">edit</i></a>
                                    <form class="form" method="POST" action="<?php echo e(route('hapus.tanaman',$list->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger btn-fab btn-fab-mini btn-round" onclick="return confirm('Apakah anda yakin ?')" >
                                            <i class="material-icons">delete</i>
                                    </button>
                                </form>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">Tambah Data Tanaman</button>

                <div class="pull-right">
                    <?php echo e($data['tanaman']->links()); ?>

                </div>

                <!-- Modal -->
                
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form class="form" method="POST" action="<?php echo e(route('tambah.tanaman')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="card-header">
                        <h4 class="description text-center text-primary">Tambah Data Tanaman</h4>
                    </div>
                    <div class="card-body">
                        <div class="form-group bmd-form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="material-icons">grass</i></div>
                                </div>
                                <input type="text" class="form-control" name="name" placeholder="Nama Tanaman...">
                            </div>
                        </div>

                        <div class="form-group bmd-form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="material-icons">date_range</i></div>
                                </div>
                                <input type="text" class="form-control" name="range" placeholder="Masa Tanam Tanaman...">
                            </div>
                        </div>

                        <div class="form-group bmd-form-group">
                            <div class="input-group">
                                <div class="col col-md-12">
                                    <label for="company" class=" form-control-label">Gambar Tanaman</label>
                                    <div class="input-group">
                                        <input type="file" id="input-fa" name="image" placeholder="Pilih Gambar..." accept="image/*" class="form-control file" data-browse-on-zone-click="true">
                                        <span class="help-block text-info">Skala Gambar harap dengan ukuran 1920x480</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Simpan Data Tanaman</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/admin/dataTanaman.blade.php ENDPATH**/ ?>