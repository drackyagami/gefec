<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\New Folder (5)\t-connect\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>