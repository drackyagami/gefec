

<?php $__env->startSection('title'); ?>
Pemberitahuan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pemberitahuan.petani'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dropdown.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Pemberitahuan</h4>
                <p class="card-category">Pemberitahuan informasi lahan pertanian para Petani</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> No </th>
                            <th> Judul </th>
                            <th> Nama Petani </th>
                            <th> Isi Pemberitahuan </th>
                            <th> Jenis </th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['notif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($data['notif']->firstItem() + $key); ?> </td>
                                <td> <?php echo e($notif->title); ?> </td>
                                <?php $petani = $data['db']::whereId($notif->user_id)->get(); ?>
                                <td> <?php echo e($petani[0]->username); ?> </td>
                                <td> <?php echo e($notif->description); ?></td>
                                <td> <?php echo e($notif->type === "Message" ? "Pesan" : "Notifikasi"); ?> </td>
                                <td>
                                    <a href="<?php echo e(route('hapus.info', $notif->id)); ?>" class="btn btn-danger btn-fab btn-fab-mini btn-round" onclick="event.preventDefault();
                                                     document.getElementById('delete-notif').submit();">
                                        <i class="material-icons">delete</i>
                                    </a>
                                    <form id="delete-notif" action="<?php echo e(route('hapus.info', $notif->id)); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#buatNotification">Buat Pemberitahuan</button>

                <div class="pull-right">
                    <?php echo e($data['notif']->links()); ?>

                </div>

                <!-- Modal -->
                <div class="modal fade" id="buatNotification" tabindex="-1" role="dialog" aria-labelledby="buatNotificationLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form class="form" method="POST" action="<?php echo e(route('tambah.info')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Buat Notifikasi</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col col-md-6 col-sm-12">
                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">rate_review</i></div>
                                                            </div>
                                                            <label for="description">Isi notifikasi atau pesan</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <textarea name="description" id="description" cols="45" rows="8"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col col-md-6 col-sm-12 mt-5">
                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">title</i></div>
                                                            </div>
                                                            <input type="text" class="form-control" name="title" placeholder="Judul">
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">face</i></div>
                                                            </div>
                                                            <input class="form-control" name="name" list="datalistOptions" placeholder="Pilih Petani...">
                                                            <datalist id="datalistOptions">
                                                                <?php $__currentLoopData = $data['petani']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user => $petani): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($petani->username); ?>"><?php echo e($petani->username); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </datalist>
                                                        </div>
                                                    </div>

                                                    <div class="form-group bmd-form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <div class="input-group-text"><i class="material-icons">alt_route</i></div>
                                                            </div>
                                                            <label class="select" for="slct">
                                                                <select id="slct" name="type" required="required">
                                                                    <option value="" disabled="disabled" selected="selected">Pilih Jenis</option>
                                                                    <option value="Message">Pesan</option>
                                                                    <option value="Notification">Notifikasi</option>
                                                                </select>
                                                                <svg>
                                                                    <use xlink:href="#select-arrow-down"></use>
                                                                </svg>
                                                            </label>
                                                            <!-- SVG Sprites-->
                                                            <svg class="sprites">
                                                                <symbol id="select-arrow-down" viewbox="0 0 10 6">
                                                                    <polyline points="1 1 5 5 9 1"></polyline>
                                                                </symbol>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan Data Tanaman</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/admin/pemberitahuanPetani.blade.php ENDPATH**/ ?>