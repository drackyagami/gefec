

<?php $__env->startSection('title'); ?>
Data Laporan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.laporan'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Riwayat Laporan</h4>
                <p class="card-category"> Daftar Riwayat Laporan Lahan Petani</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> Kode </th>
                            <th> Petani </th>
                            <th> Lahan </th>
                            <th> Waktu Lapor </th>
                            <th> Sampel Gambar </th>
                            <th> Hasil </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['laporan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($list->code); ?> </td>
                                <?php $petani = $data['petani']::find($list->user_id); ?>
                                <td> <?php echo e($petani->username); ?> </td>
                                <?php $lahan = $data['lahan']::find($list->land_id); ?>
                                <td> <?php echo e($lahan->name); ?> </td>
                                <td> <?php echo e($list->created_at); ?> </td>
                                <td>
                                    <button class="btn btn-primary btn-just-icon btn-sm" data-toggle="modal" data-target="#sampleImage<?php echo e($list->code); ?>">
                                        <i class="material-icons">image</i>
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="sampleImage<?php echo e($list->code); ?>" tabindex="-1" role="dialog" aria-labelledby="sampleImage<?php echo e($list->code); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="sampleImage<?php echo e($list->code); ?>Label">Gambar sampel tanaman</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <img class="img-fluid" src="<?php echo e(asset('image/report/'. $list->sample)); ?>" alt="">
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="" class="btn btn-primary" data-dismiss="modal">Tutup</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('detail.laporan', $list->code)); ?>" class="btn btn-primary btn-sm">
                                        Lihat Hasil
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <div class="pull-right">
                    <?php echo e($data['laporan']->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New Folder (5)\t-connect\resources\views/admin/dataLaporan.blade.php ENDPATH**/ ?>