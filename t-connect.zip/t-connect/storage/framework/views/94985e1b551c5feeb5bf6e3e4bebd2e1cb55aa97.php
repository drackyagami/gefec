

<?php $__env->startSection('title'); ?>
Edit Data Lahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.lahan'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Edit lahan</h4>
          </div>
          <div class="card-body">
            
            <form method="POST" action="/petani/updatelahan/<?php echo e($lahan->id); ?>">
              <div class="row">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-12">
                  <label class="bmd-label-floating">Nama Lahan</label>
                  <div class="form-group">
  
                    <input type="text" name="name"class="form-control" value="<?php echo e($lahan->name); ?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <label class="bmd-label-floating">Longitude </label>
                  <div class="form-group">
  
                    <input type="text" name="long"class="form-control" value="<?php echo e($lahan->long); ?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Langitude</label>
                  <div class="form-group">
  
                    <input type="text" name="lat"class="form-control" value="<?php echo e($lahan->lat); ?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <label class="bmd-label-floating">Luas Lahan</label>
                  <div class="form-group">
  
                    <input type="text" name="large"class="form-control" value="<?php echo e($lahan->large); ?>">
                  </div>
                </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Alamat Lahan</label>
                  <div class="form-group">
  
                    <input type="text" name="address"class="form-control" value="<?php echo e($lahan->address); ?>">
                  </div>
                </div>
              </div>
                <div class="col-md-6">
                  <label class="bmd-label-floating">Kabupaten/kota</label>
                  <div class="form-group">
  
                    <input type="text" name="city"class="form-control" value="<?php echo e($lahan->city); ?>">
                  </div>
                </div>
  
                <div class="col-md-6">
                  <label class="bmd-label-floating">Provinsi</label>
                  <div class="form-group">
                    <input type="text" name ="province" class="form-control" value="<?php echo e($lahan->province); ?>">
                  </div>
                </div>
              </div>
  
              <input type="submit" class="btn btn-primary pull-right" value="Update">
              <div class="clearfix"></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/petani/edit-tanaman.blade.php ENDPATH**/ ?>