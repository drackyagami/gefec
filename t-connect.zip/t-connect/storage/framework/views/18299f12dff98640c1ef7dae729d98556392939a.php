

<?php $__env->startSection('title'); ?>
Edit Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('data.profilepetani'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Edit Profile</h4>
          
        </div>
        <div class="card-body">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eror): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="alert alert-danger alert-block">
            Data Harus di isi
            </div>
          
              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($message = Session::get('message')): ?>
            <div class="alert alert-danger alert-block">
              <?php echo e($message); ?>

            </div> 
            <?php endif; ?>
          <form method="POST" action="<?php echo e(route('edit.petani.profile')); ?>">
            <div class="row">
              <?php echo e(csrf_field()); ?>

              <div class="col-md-12">
                <label class="bmd-label-floating">Username</label>
                <div class="form-group">

                  <input type="text" name="username"class="form-control" value="<?php echo e(Auth::user()->username); ?>">
                </div>
              </div>
              <div class="col-md-12">
                <label class="bmd-label-floating">Email </label>
                <div class="form-group">

                  <input type="email" name="email"class="form-control" value="<?php echo e(Auth::user()->email); ?>">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <label class="bmd-label-floating">Alamat</label>
                <div class="form-group">

                  <input type="text" name="address"class="form-control" value="<?php echo e(Auth::user()->address); ?>">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <label class="bmd-label-floating">Kota</label>
                <div class="form-group">

                  <input type="text" name="city"class="form-control" value="<?php echo e(Auth::user()->city); ?>">
                </div>
              </div>
              <div class="col-md-6">
                <label class="bmd-label-floating">Provinsi</label>
                <div class="form-group">

                  <input type="text" name="province"class="form-control" value="<?php echo e(Auth::user()->province); ?>">
                </div>
              </div>

              <div class="col-md-12">
                <label class="bmd-label-floating">Tanggal Lahir</label>
                <div class="form-group">
                  <input type="date" name ="birth" class="form-control" value="<?php echo e(Auth::user()->birth); ?>">
                </div>
              </div>
            </div>

            <button type="submit" class="btn btn-primary pull-right">Update Profile</button>
            <div class="clearfix"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New Folder (5)\t-connect\resources\views/petani/profile.blade.php ENDPATH**/ ?>