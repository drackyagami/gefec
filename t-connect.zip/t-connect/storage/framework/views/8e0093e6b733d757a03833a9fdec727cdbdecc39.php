

<?php $__env->startSection('title'); ?>
Edit Data hama
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('edit.data.hama'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Edit Hama</h4>
          </div>
          <div class="card-body">
            
            <form method="POST" action="" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Nama Hama</label>
                  <div class="form-group">
  
                    <input type="text" name="name"class="form-control" value="<?php echo e($data->name); ?>">
                  </div>
                </div>
                
                <div class="col">
                  <label class="bmd-label-floating">Gambar Hama</label>
                  <div class="form-row">
                    <div class="col">
                        <img src="<?php echo e(asset('image/pest/'.$data->image)); ?>" alt="" width="80">
                    </div>
                    <div class="col">
                      <input type="file" name="image"class="form-control">
                    </div>
                  </div>
                </div>
              <div class="col-md-12">
                <label class="bmd-label-floating">Gejala </label>
                <div class="form-group">

                  <textarea type="text" name="range"class="form-control" value=""rows="5"><?php echo e($data->symptom->detail); ?></textarea>
                </div>
              </div>
            
            <div class="col-md-12 ">
                <label class="bmd-label-floating">Penanganan </label>
                <div class="form-group">

                  <textarea type="text" name="range"class="form-control" value=""rows="5"><?php echo e($data->action->detail); ?></textarea>
                </div>
              </div>
            
              <input type="submit" class="btn btn-primary ml-auto" value="Update">
              <div class="clearfix"></div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/admin/edit-datahama.blade.php ENDPATH**/ ?>