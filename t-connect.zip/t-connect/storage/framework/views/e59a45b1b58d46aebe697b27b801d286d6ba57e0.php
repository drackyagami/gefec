

<?php $__env->startSection('title'); ?>
Ganti Password
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('data.passwordptn'); ?>
active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Ganti Password</h4>
        </div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('edit.petani.editpassword')); ?>">
            <?php echo e(csrf_field()); ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eror): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-block">
              Password baru dan konfirmasi password harus sama
              </div>
            
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($message = Session::get('message')): ?>
              <div class="alert alert-danger alert-block">
                <?php echo e($message); ?>

              </div>    
            <?php endif; ?>
            <div class="row">
              <div class="col-md-12">
                <label class="bmd-label-floating">Passowrd Lama</label>
                <div class="form-group">

                  <input type="password"name="password_lama" class="form-control">
                </div>
              </div>
              <div class="col-md-12">
                <label class="bmd-label-floating">Password Baru </label>
                <div class="form-group">

                  <input type="password" name="password_baru"class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <label class="bmd-label-floating">Konfirmasi Password Baru</label>
                <div class="form-group">

                  <input type="password"name="konfirmasi_password" class="form-control">
                </div>
              </div>
            </div>


            <button type="submit" class="btn btn-primary pull-right">Ganti Password</button>
            <div class="clearfix"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/petani/passwordptn.blade.php ENDPATH**/ ?>