

<?php $__env->startSection('title'); ?>
Data Hama
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.hama'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Hama</h4>
                
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> No </th>
                            <th> Nama </th>
                            <th> Tanaman </th>
                            <!-- <th> Gambar </th>
                            <th> Gejala </th>
                            <th> Tindakan </th> -->
                            
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php $key = 1; ?>
                            <?php $__currentLoopData = $data['hama']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($data['hama']->firstItem() + $key); ?> </td>
                                <td> <?php echo e($list->name); ?> </td>
                                <td> <?php echo e($list->plant_target); ?> </td>
                                <!-- <td> <img src="<?php echo e(asset('image/pest/'.$list->image)); ?>" alt="<?php echo e($list->image); ?>" style="max-height: 150px;"> </td> -->
                                <!-- <td>
                                    Oud-Turnhout
                                </td>
                                <td>
                                    Oud-Turnhout
                                </td> -->
                         
                                <td>
                                    <a href="<?php echo e(route('detail.hama', $list->id)); ?>" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">visibility</i>
                                    </a>
                                    
                                    <form class="form" method="POST" action="<?php echo e(route('hapus.hama',$list->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger btn-fab btn-fab-mini btn-round" onclick="return confirm('Apakah anda yakin ?')" >
                                            <i class="material-icons">delete</i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php $key++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahHama">Tambah Data Hama</button>

                <div class="pull-right">
                    <?php echo e($data['hama']->links()); ?>

                </div>
            
                <!-- Modal -->
                <div class="modal fade" id="tambahHama" tabindex="-1" role="dialog" aria-labelledby="tambahHamaLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form class="form" method="POST" action="<?php echo e(route('tambah.hama')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Tambah Data Hama</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">bug_report</i></div>
                                                </div>
                                                <input type="text" class="form-control" name="name" placeholder="Nama Hama/Penyakit...">
                                            </div>
                                        </div>

                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">grass</i></div>
                                                </div>
                                                <input type="text" class="form-control" name="plant" list="datalistOptions" placeholder="Nama Tanaman target...">
                                                <datalist id="datalistOptions">
                                                    <?php $__currentLoopData = $data['tanaman']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant => $tanaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($tanaman->name); ?>"><?php echo e($tanaman->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </datalist>
                                            </div>
                                        </div>

                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="col col-md-12">
                                                    <label for="company" class=" form-control-label">Gambar Hama</label>
                                                    <div class="input-group">
                                                        <input type="file" id="input-fa" name="image" placeholder="Pilih Gambar..." accept="image/*" class="form-control file" data-browse-on-zone-click="true">
                                                        <span class="help-block text-info">Skala Gambar harap dengan ukuran 1920x480</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan Data Hama</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New Folder (5)\t-connect\resources\views/admin/dataHama.blade.php ENDPATH**/ ?>