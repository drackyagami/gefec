

<?php $__env->startSection('title'); ?>
Detail Lahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<style>
    #mapid {
        height: 100%;
    }

    .card {
        height: 520px;
        margin-bottom: 0;
    }

    .hcard {
        height: 320px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.petani'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Detail Lahan</h4>
                <p class="card-category">Detail Lahan <b><?php echo e($data['lahan']->name); ?></b> Milik Petani <b><?php echo e($data['petani']->username); ?></b></p>
            </div>
            <div class="card-body">
                <div class="container">
                    <div class="row">
                        <div class="col col-md-8 hcard">
                            <div id="mapid"></div>
                        </div>
                        <div class="col col-md-4">
                            <h3><b>Komposisi Data Lahan</b></h3>
                            <table>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Nama Lahan</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;"><?php echo e($data['lahan']->name); ?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Terdaftar Sejak</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;"><?php echo e($data['lahan']->created_at); ?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Status</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <?php if($data['lahan']->status == true): ?>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Dipakai</h6>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Menganggur</h6>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Jumlah Tanaman</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <!-- PR -->
                                    <td>
                                        <h6 style="text-transform: capitalize;"> <?php echo e($data['jmltnm']); ?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Tanaman Dipanen</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <!-- PR -->
                                    <td>
                                        <h6 style="text-transform: capitalize;"> <?php echo e($data['jmlpnn']); ?> </h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Alamat Lahan</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;" style="text-decoration: none;"><?php echo e($data['lahan']->address); ?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Kota/Kabupaten</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;" style="text-decoration: none;"><?php echo e($data['lahan']->city); ?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 style="text-transform: capitalize;">Provinsi</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;">:</h6>
                                    </td>
                                    <td>
                                        <h6 style="text-transform: capitalize;" style="text-decoration: none;"><?php echo e($data['lahan']->province); ?></h6>
                                    </td>
                                </tr>
                            </table>
                        </div>

                </div>   
                
            </div>
        </div>
    </div>

</div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th> No </th>
                            <th> Tanaman </th>
                            <th> Tanggal Tanam </th>
                            <th> Umur Tanaman </th>
                            <th> Status </th>
                            
                        </thead>
                        <tbody>
                            <?php
                            $no=0;?>
                            <?php $__currentLoopData = $data['tanaman']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $no++;?>
                            <tr>
                                <td> <?php echo e($no); ?> </td>
                                <td> <?php echo e($list->name); ?> </td>
                                <td> <?php echo e(date('d-m-Y',strtotime($list->planting))); ?> </td>
                                <td>  
                                    <?php
                                        $awal  = strtotime($list->planting);
                                        $akhir = time();
                                        $masa  = $akhir - $awal;
                                        $tanam = floor($masa / (60 * 60 * 24));
                                        echo $tanam." hari";
                                    ?>
                                </td>
                                <td>  
                                    <?php if($list->status == true): ?>
                                    <span class="badge badge-secondary">Sudah Panen</span>
                                    <?php else: ?>
                                    <span class="badge badge-success">Belum Panen</span>
                                    <?php endif; ?>
                                </td>
                              
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div> 
                </div>
                </div> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Leaflet Plugin    -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<script>
    var latlon = <?php echo json_encode($data['lahan']->toArray()); ?>;
    console.log(latlon);
    var mymap = L.map('mapid').setView([latlon.lat, latlon.long], 13);
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=sk.eyJ1IjoibmlkdW1pbGEiLCJhIjoiY2txYjNtOG0wMGV1bDJva2RjNnoxc3JxdyJ9.C0xjMED4KtNFHkvMof8nbg', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'your.mapbox.access.token'
    }).addTo(mymap);

    var marker = L.marker([latlon.lat, latlon.long]).addTo(mymap);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/admin/detailLahan.blade.php ENDPATH**/ ?>