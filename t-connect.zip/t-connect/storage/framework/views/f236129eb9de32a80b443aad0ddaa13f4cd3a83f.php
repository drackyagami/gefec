

<?php $__env->startSection('title'); ?>
Data Hama
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.hama'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Hama</h4>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>Kode </th>
                            <th>Lahan</th>
                            <th>Tanaman </th>
                            <th>Jenis Hama</th>
                            <th>Diagnosis</th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['report']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($list['code']); ?> </td>
                                <?php
                                    $land = $data['lahan']::find($list['land_id']);
                                ?>
                                <td> <?php echo e($land->name); ?> </td>
                                <?php
                                    $plant = $data['plant']::find($land->plant_id);
                                ?>
                                <td> <?php echo e($plant->name); ?> </td>
                                <?php
                                    $result = $data['result']::whereReport_code($list['code'])->first();;
                                    $hama = $result == null ? "" : $data['pest']::find($result['pest_id']);
                                ?>
                                <td> <?php echo e($hama == null ? "" : $hama->name); ?> </td>
                                <td>
                                    <img class="rounded img-fluid d-block my-4" src="<?php echo e(asset('image/report/'.$list['sample'])); ?>" style="height: 100px !important;">
                                </td>
                                <td>
                                    <a href="" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">visibility</i>
                                    </a>
                                    <button class="btn btn-warning btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">edit</i>
                                    </button>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New Folder (5)\t-connect\resources\views/petani/hamapetani.blade.php ENDPATH**/ ?>