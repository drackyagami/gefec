

<?php $__env->startSection('title'); ?>
Edit Data tanaman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('edit.data.tanaman'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Edit Tanaman</h4>
          </div>
          <div class="card-body">
            
            <form method="POST" action="<?php echo e(route('edit.tanaman',$data->id)); ?>" enctype="multipart/form-data">
              <div class="row">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-12">
                  <label class="bmd-label-floating">Nama Tanaman</label>
                  <div class="form-group">
  
                    <input type="text" name="name"class="form-control" value="<?php echo e($data->name); ?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <label class="bmd-label-floating">Masa Tanaman </label>
                  <div class="form-group">
  
                    <input type="number" name="range"class="form-control" value="<?php echo e($data->planting_time); ?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="bmd-label-floating">Gambar Tanaman</label>
                  <div class="form-row">
                    <div class="col">
                        <img src="<?php echo e(asset('image/plant/'.$data->image)); ?>" alt="" width="100">
                    </div>
                    <div class="col">
                      <input type="file" name="image"class="form-control">

                    </div>
  
                  </div>
                </div>
              </div>
              <input type="submit" class="btn btn-primary pull-right" value="Update">
              <div class="clearfix"></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/admin/edit-datatanaman.blade.php ENDPATH**/ ?>