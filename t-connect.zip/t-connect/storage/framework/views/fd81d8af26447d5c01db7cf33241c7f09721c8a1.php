<?php echo e($slot); ?>

<?php /**PATH E:\t-connect\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>