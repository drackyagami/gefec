<?php echo e($slot); ?>

<?php /**PATH D:\New Folder (5)\t-connect\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>