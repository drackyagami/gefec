

<?php $__env->startSection('title'); ?>
Data Petani
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.petani'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Petani</h4>
                <p class="card-category"> Daftar Petani terdaftar Tani Modern Connect</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="petani">
                        <thead class=" text-primary">
                            <th> No. </th>
                            <th> Nama </th>
                            <th> Email </th>
                            <th> Alamat </th>
                            <th> Kota/Kabupaten </th>
                            <th> Provinsi </th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['petani']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($data['petani']->firstItem() + $key); ?> </td>
                                <td> <?php echo e($list->username); ?> </td>
                                <td> <?php echo e($list->email); ?> </td>
                                <td> <?php echo e($list->address); ?> </td>
                                <td> <?php echo e($list->city); ?> </td>
                                <td> <?php echo e($list->province); ?> </td>
                                <td>
                                    <a href="<?php echo e(route('data.lahan', $list->id)); ?>" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">auto_stories</i>
                                    </a>
                                   
                                    <form class="form" method="POST" action="<?php echo e(route('hapus.petani',$list->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">do_not_disturb_on</i>
                                    </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <div class="pull-right">
                    <?php echo e($data['petani']->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#petani').DataTable();} 
    );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\t-connect\resources\views/admin/dataPetani.blade.php ENDPATH**/ ?>