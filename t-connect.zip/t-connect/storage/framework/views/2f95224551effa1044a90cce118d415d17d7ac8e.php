<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>T-Connect</title>

    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/logo.png')); ?>" type="image/x-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/auth.css')); ?>">
</head>

<body class="antialiased">
    <!-- Form-->
    <div class="form">
        <div class="form-toggle"></div>
        <div class="form-panel">
            <div class="form-header">
                <h1>Account Login</h1>
            </div>
            <?php if(session('error')): ?>
            <div class="alert alert-danger mt-2" role="alert">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('status')): ?>
            <div class="mb-4 font-medium text-sm text-green-600">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <div class="form-content">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="email"><?php echo e(__('Email')); ?></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" autofocus />
                    </div>
                    <div class="form-group">
                        <label for="password"><?php echo e(__('Password')); ?></label>
                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php if(session('status')): ?>is-invalid <?php endif; ?>" id="password" name="password" autocomplete="current-password" />
                    </div>
                    <div class="form-group">
                        <label class="form-remember">
                            <input type="checkbox" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> /><?php echo e(__('Remember me')); ?>

                        </label>
                            <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot your password?')); ?>

                        </a>
                    </div>
                    <div class="form-group">
                        <button type="submit"><?php echo e(__('Login')); ?></button>
                    </div>
                    <div class="form-group">
                        <a class="form-recovery" href="<?php echo e(route('register')); ?>"><?php echo e(__("Don't have an Account? Register")); ?></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/core/jquery.min.js"></script>
    <script src="assets/js/auth.js">
    </script>
</body>

</html><?php /**PATH D:\New Folder (5)\t-connect\resources\views/welcome.blade.php ENDPATH**/ ?>