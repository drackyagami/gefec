

<?php $__env->startSection('title'); ?>
Dashboard Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">person</i>
                </div>
                <p class="card-category">Jumlah Petani</p>
                <h3 class="card-title"><?php echo e($data['petani']); ?> Orang
                </h3>
            </div>
            <div class="card-footer">
                <div class="stats"> 
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">store</i>
                </div>
                <p class="card-category">Pemanenan</p>
                <h3 class="card-title"><?php echo e($data['pemanenan']); ?>

                </h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">info_outline</i>
                </div>
                <p class="card-category">Deteksi Hama</p>
                <h3 class="card-title"><?php echo e($data['diagnosa']); ?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">area_chart</i>
                </div>
                <p class="card-category">Jumlah Lahan</p>
                <h3 class="card-title"><?php echo e($data['lahan']); ?>

                    
                </h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New Folder (5)\t-connect\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>