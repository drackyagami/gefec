

<?php $__env->startSection('title'); ?>
Data Tanaman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('data.tanaman'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Tanaman</h4>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="tanaman">
                        <thead class=" text-primary">
                            <th> ID </th>
                            <th> Nama Lahan </th>
                            <th> Nama Tanaman </th>
                            <th> Tanggal tanam</th>
                            <th> Umur Tanaman </th>
                            <th> Masa Tanam </th>
                            <th> Status Tanaman </th>
                            <th> Aksi </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['lahan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($key + 1); ?> </td>
                                <td> <?php echo e($list->name); ?> </td>
                                <?php
                                    $tanaman = $data['plant']::whereId($list->plant_id)->first();
                                ?>
                                <td> <?php echo e($tanaman['name']); ?> </td>
                                <td> <?php echo e(date('d-m-Y',strtotime($list->planting))); ?>

                                 </td>
                                 <?php if($list->status === true): ?>
                                    <?php
                                        $awal = $list->planting;
                                        $akhir = $list->updated_at;

                                        $selisih = \Carbon\Carbon::parse($awal)->diffInDays($akhir)
                                    ?>
                                 <td><?php echo e($selisih); ?> Hari</td>
                                 <?php else: ?>
                                 <td> 
                                     <?php
                                         $awal  = strtotime($list->planting);
                                         $akhir = time();
                                         $masa  = $akhir - $awal;
                                         $tanam = floor($masa / (60 * 60 * 24));
 
                                         echo $tanam . " hari";
 
                                         
                                     ?>
                                 </td>
                                     
                                 <?php endif; ?>
                                <td> <?php echo e($tanaman['planting_time']); ?> hari </td>
                                <td>
                                   
                                    <?php if($list->status == true): ?>
                                    <span class="badge badge-success">Sudah Panen</span>
                                    <?php else: ?>
                                    <span class="badge badge-secondary">Belum Panen</span>
                                    <?php endif; ?>
                                    
                                </td>
                                <td>
                                    <form class="form" method="POST" action="<?php echo e(route('ganti.petani.status',$list->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    
                                    <button name="status" type="submit" class="btn btn-primary btn-fab btn-fab-mini btn-round">
                                        <i class="material-icons">local_florist</i>
                                    </button>
                                    </form>
                                    
                                        <form class="form" method="POST" action="<?php echo e(route('hapus.petani.tanaman',$list->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger btn-fab btn-fab-mini btn-round" onclick="return confirm('Apakah anda yakin ?')" >
                                            <i class="material-icons">delete</i>
                                
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">Tambah Data Tanaman</button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form class="form" method="POST" action="<?php echo e(route('tambah.petani.tanaman')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="card-header">
                                        <h4 class="description text-center text-primary">Tambah Data Tanaman</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">pin_drop</i></div>
                                                </div>
                                                <select class="form-control" name="land" required>
                                                    <option disabled selected hidden>Pilih Lahan....</option>
                                                    <?php $__currentLoopData = $data['land']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $land): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($land->id); ?>">[LID<?php echo e($land->id); ?>] <?php echo e($land->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">grass</i></div>
                                                </div>
                                                <select class="form-control" name="plant" required>
                                                    <option disabled selected hidden>Pilih Tanaman....</option>
                                                    <?php 
                                                        $tanaman = $data['plant']::all();
                                                    ?>
                                                    <?php $__currentLoopData = $tanaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $tanaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($tanaman->id); ?>">[PID<?php echo e($tanaman->id); ?>] <?php echo e($tanaman->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                
                                            </div>
                                        </div>

                                        <div class="form-group bmd-form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="material-icons">date_range</i></div>
                                                </div>
                                                <input type="date" class="form-control" name="date" max="<?php echo e(Carbon\Carbon::now()->toDateString()); ?>" placeholder="Masa Tanam Tanaman..." required>
                                            </div>
                                        </div>

                                        

                                    </div>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Simpan Data Tanaman</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#tanaman').DataTable();} 
    );

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New Folder (5)\t-connect\resources\views/petani/datatanaman.blade.php ENDPATH**/ ?>